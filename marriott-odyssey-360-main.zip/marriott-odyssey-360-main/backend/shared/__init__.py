"""
Shared utilities and middleware for Marriott's Odyssey 360 AI
"""


