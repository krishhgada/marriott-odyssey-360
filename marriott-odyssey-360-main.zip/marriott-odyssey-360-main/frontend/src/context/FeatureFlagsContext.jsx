import React, { createContext, useContext } from 'react';

// Feature flags configuration
const featureFlags = {
  privacy: process.env.REACT_APP_FEATURE_PRIVACY !== 'false',
  culture: process.env.REACT_APP_FEATURE_CULTURE !== 'false',
  trustlens: process.env.REACT_APP_FEATURE_TRUSTLENS !== 'false',
  intermodal: process.env.REACT_APP_FEATURE_INTERMODAL !== 'false',
  agentops: process.env.REACT_APP_FEATURE_AGENTOPS !== 'false',
  insights: process.env.REACT_APP_FEATURE_INSIGHTS !== 'false',
};

// Create context
const FeatureFlagsContext = createContext(featureFlags);

/**
 * Feature Flags Provider Component
 * Provides feature flag configuration to all child components
 */
export const FeatureFlagsProvider = ({ children }) => {
  return (
    <FeatureFlagsContext.Provider value={featureFlags}>
      {children}
    </FeatureFlagsContext.Provider>
  );
};

/**
 * Hook to access feature flags
 * @returns {Object} Feature flags object
 * 
 * @example
 * const flags = useFeatureFlags();
 * if (flags.privacy) {
 *   // Render privacy feature
 * }
 */
export const useFeatureFlags = () => {
  const context = useContext(FeatureFlagsContext);
  if (context === undefined) {
    throw new Error('useFeatureFlags must be used within a FeatureFlagsProvider');
  }
  return context;
};

/**
 * Check if a specific feature is enabled
 * @param {string} feature - Feature name
 * @returns {boolean} Whether the feature is enabled
 * 
 * @example
 * const isPrivacyEnabled = isFeatureEnabled('privacy');
 */
export const isFeatureEnabled = (feature) => {
  return featureFlags[feature] === true;
};

export default FeatureFlagsContext;


