import React from 'react';
import { NavLink } from 'react-router-dom';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { 
  Home, 
  MessageCircle, 
  Home as RoomIcon, 
  Heart, 
  MapPin, 
  Settings,
  X,
  User,
  LogOut,
  Shield,
  Globe,
  CheckCircle,
  Navigation as NavigationIcon,
  Users,
  Activity,
  TrendingUp
} from 'lucide-react';
import { useFeatureFlags } from '../context/FeatureFlagsContext';

const SidebarContainer = styled(motion.aside)`
  position: fixed;
  top: 0;
  left: 0;
  width: 280px;
  height: 100vh;
  background: ${props => props.theme.cardBackground};
  border-right: 1px solid ${props => props.theme.border};
  z-index: 200;
  display: flex;
  flex-direction: column;
  backdrop-filter: blur(10px);
  box-shadow: ${props => props.theme.shadowMedium};

  @media (max-width: 768px) {
    transform: ${props => props.isOpen ? 'translateX(0)' : 'translateX(-100%)'};
    transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  }
`;

const SidebarHeader = styled.div`
  padding: 2rem 1.5rem 1rem;
  border-bottom: 1px solid ${props => props.theme.border};
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const CloseButton = styled(motion.button)`
  background: none;
  border: none;
  color: ${props => props.theme.text};
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.theme.hoverBackground};
  }

  @media (min-width: 769px) {
    display: none;
  }
`;

const Logo = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  font-size: 1.25rem;
  font-weight: 700;
  color: ${props => props.theme.primary};

  .logo-icon {
    width: 40px;
    height: 40px;
    background: ${props => props.theme.gradient};
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    font-size: 1.25rem;
  }
`;

const Navigation = styled.nav`
  flex: 1;
  padding: 1.5rem 0;
  overflow-y: auto;
`;

const NavSection = styled.div`
  margin-bottom: 2rem;

  &:last-child {
    margin-bottom: 0;
  }
`;

const SectionTitle = styled.h3`
  font-size: 0.75rem;
  font-weight: 600;
  color: ${props => props.theme.textSecondary};
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-bottom: 0.75rem;
  padding: 0 1.5rem;
`;

const NavItem = styled(NavLink)`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem 1.5rem;
  color: ${props => props.theme.text};
  text-decoration: none;
  transition: ${props => props.theme.transition};
  position: relative;
  font-weight: 500;

  &:hover {
    background: ${props => props.theme.hoverBackground};
    color: ${props => props.theme.primary};
  }

  &.active {
    background: ${props => props.theme.primary}15;
    color: ${props => props.theme.primary};
    border-right: 3px solid ${props => props.theme.primary};

    &::before {
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      width: 3px;
      background: ${props => props.theme.primary};
    }
  }

  .nav-icon {
    width: 20px;
    height: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
`;

const UserSection = styled.div`
  padding: 1.5rem;
  border-top: 1px solid ${props => props.theme.border};
  background: ${props => props.theme.hoverBackground};
`;

const UserInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin-bottom: 1rem;

  .user-avatar {
    width: 40px;
    height: 40px;
    background: ${props => props.theme.gradient};
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 600;
  }

  .user-details {
    flex: 1;

    .user-name {
      font-weight: 600;
      font-size: 0.875rem;
      margin-bottom: 0.25rem;
    }

    .user-email {
      font-size: 0.75rem;
      color: ${props => props.theme.textSecondary};
    }
  }
`;

const LogoutButton = styled(motion.button)`
  width: 100%;
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem;
  background: none;
  border: 1px solid ${props => props.theme.border};
  color: ${props => props.theme.text};
  border-radius: 8px;
  cursor: pointer;
  transition: ${props => props.theme.transition};
  font-weight: 500;

  &:hover {
    background: ${props => props.theme.error}15;
    border-color: ${props => props.theme.error};
    color: ${props => props.theme.error};
  }
`;

const Overlay = styled(motion.div)`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 150;
  backdrop-filter: blur(4px);

  @media (min-width: 769px) {
    display: none;
  }
`;

const Sidebar = ({ isOpen, onClose, isAuthenticated, user, onLogout }) => {
  const flags = useFeatureFlags();
  
  const navItems = [
    {
      section: 'Main',
      items: [
        { to: '/', icon: Home, label: 'Dashboard' },
        { to: '/concierge', icon: MessageCircle, label: 'AI Concierge' },
        { to: '/room', icon: RoomIcon, label: 'Room Control' },
      ]
    },
    {
      section: 'Services',
      items: [
        { to: '/wellness', icon: Heart, label: 'Wellness & Safety' },
        { to: '/discovery', icon: MapPin, label: 'Local Discovery' },
      ]
    },
    {
      section: 'New Features',
      items: [
        flags.privacy && { to: '/privacy', icon: Shield, label: 'Privacy Controller' },
        flags.culture && { to: '/culture', icon: Globe, label: 'Culture & Access' },
        flags.trustlens && { to: '/trustlens', icon: CheckCircle, label: 'TrustLens' },
        flags.intermodal && { to: '/intermodal', icon: NavigationIcon, label: 'Door-to-Door' },
        flags.agentops && { to: '/agentops', icon: Users, label: 'AgentOps' },
        flags.insights && { to: '/mood', icon: Activity, label: 'Mood & Wellness' },
        { to: '/metrics', icon: TrendingUp, label: 'Metrics' },
      ].filter(Boolean)
    },
    {
      section: 'Account',
      items: [
        { to: '/settings', icon: Settings, label: 'Settings' },
      ]
    }
  ];

  return (
    <>
      {isOpen && (
        <Overlay
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        />
      )}
      
      <SidebarContainer
        isOpen={isOpen}
        initial={{ x: -280 }}
        animate={{ x: isOpen ? 0 : -280 }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      >
        <SidebarHeader>
          <Logo>
            <div className="logo-icon">M</div>
            <span>Odyssey 360</span>
          </Logo>
          <CloseButton
            onClick={onClose}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <X size={20} />
          </CloseButton>
        </SidebarHeader>

        <Navigation>
          {navItems.map((section, sectionIndex) => (
            <NavSection key={sectionIndex}>
              <SectionTitle>{section.section}</SectionTitle>
              {section.items.map((item, itemIndex) => (
                <NavItem
                  key={itemIndex}
                  to={item.to}
                  onClick={onClose}
                >
                  <div className="nav-icon">
                    <item.icon size={20} />
                  </div>
                  {item.label}
                </NavItem>
              ))}
            </NavSection>
          ))}
        </Navigation>

        {isAuthenticated && user && (
          <UserSection>
            <UserInfo>
              <div className="user-avatar">
                {user.first_name?.charAt(0) || 'U'}
              </div>
              <div className="user-details">
                <div className="user-name">
                  {user.first_name} {user.last_name}
                </div>
                <div className="user-email">{user.email}</div>
              </div>
            </UserInfo>
            
            <LogoutButton
              onClick={onLogout}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <LogOut size={16} />
              Sign Out
            </LogoutButton>
          </UserSection>
        )}
      </SidebarContainer>
    </>
  );
};

export default Sidebar;
