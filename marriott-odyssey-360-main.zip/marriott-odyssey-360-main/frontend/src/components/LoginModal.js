import React, { useState } from 'react';
import styled from 'styled-components';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Mail, Lock, User, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import toast from 'react-hot-toast';

const ModalOverlay = styled(motion.div)`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(4px);
`;

const ModalContainer = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  border-radius: 20px;
  padding: 2rem;
  width: 90%;
  max-width: 400px;
  box-shadow: ${props => props.theme.shadowStrong};
  border: 1px solid ${props => props.theme.border};
  position: relative;
`;

const CloseButton = styled(motion.button)`
  position: absolute;
  top: 1rem;
  right: 1rem;
  background: none;
  border: none;
  color: ${props => props.theme.textSecondary};
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.theme.hoverBackground};
    color: ${props => props.theme.text};
  }
`;

const ModalHeader = styled.div`
  text-align: center;
  margin-bottom: 2rem;
`;

const Logo = styled.div`
  width: 60px;
  height: 60px;
  background: ${props => props.theme.gradient};
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 1.5rem;
  font-weight: bold;
  margin: 0 auto 1rem;
`;

const Title = styled.h2`
  font-size: 1.5rem;
  font-weight: 700;
  color: ${props => props.theme.text};
  margin-bottom: 0.5rem;
`;

const Subtitle = styled.p`
  color: ${props => props.theme.textSecondary};
  font-size: 0.875rem;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const InputGroup = styled.div`
  position: relative;
`;

const Input = styled.input`
  width: 100%;
  padding: 0.75rem 1rem 0.75rem 2.5rem;
  border: 1px solid ${props => props.theme.border};
  border-radius: 12px;
  background: ${props => props.theme.background};
  color: ${props => props.theme.text};
  font-size: 0.875rem;
  transition: ${props => props.theme.transition};

  &:focus {
    outline: none;
    border-color: ${props => props.theme.primary};
    box-shadow: 0 0 0 3px ${props => props.theme.primary}20;
  }

  &::placeholder {
    color: ${props => props.theme.textSecondary};
  }
`;

const InputIcon = styled.div`
  position: absolute;
  left: 0.75rem;
  top: 50%;
  transform: translateY(-50%);
  color: ${props => props.theme.textSecondary};
  display: flex;
  align-items: center;
  justify-content: center;
`;

const PasswordToggle = styled(motion.button)`
  position: absolute;
  right: 0.75rem;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  color: ${props => props.theme.textSecondary};
  cursor: pointer;
  padding: 0.25rem;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: ${props => props.theme.transition};

  &:hover {
    color: ${props => props.theme.text};
    background: ${props => props.theme.hoverBackground};
  }
`;

const Button = styled(motion.button)`
  width: 100%;
  padding: 0.75rem 1rem;
  background: ${props => props.theme.gradient};
  color: white;
  border: none;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: ${props => props.theme.transition};
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;

  &:hover {
    transform: translateY(-1px);
    box-shadow: ${props => props.theme.shadowMedium};
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`;

const ToggleMode = styled.div`
  text-align: center;
  margin-top: 1rem;
`;

const ToggleButton = styled.button`
  background: none;
  border: none;
  color: ${props => props.theme.primary};
  cursor: pointer;
  font-weight: 500;
  text-decoration: underline;
  transition: ${props => props.theme.transition};

  &:hover {
    color: ${props => props.theme.primaryDark};
  }
`;

const DemoButton = styled(motion.button)`
  width: 100%;
  padding: 0.75rem 1rem;
  background: ${props => props.theme.hoverBackground};
  color: ${props => props.theme.text};
  border: 1px solid ${props => props.theme.border};
  border-radius: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: ${props => props.theme.transition};
  margin-bottom: 1rem;

  &:hover {
    background: ${props => props.theme.border};
    transform: translateY(-1px);
  }
`;

const LoginModal = ({ onClose, onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    firstName: '',
    lastName: ''
  });

  const { login, register, isLoggingIn, isRegistering } = useAuth();

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      if (isLogin) {
        await login({
          email: formData.email,
          password: formData.password
        });
        onClose();
      } else {
        await register({
          email: formData.email,
          password: formData.password,
          first_name: formData.firstName,
          last_name: formData.lastName
        });
        setIsLogin(true);
        setFormData({
          email: '',
          password: '',
          firstName: '',
          lastName: ''
        });
      }
    } catch (error) {
      console.error('Auth error:', error);
    }
  };

  const handleDemoLogin = async () => {
    try {
      await login({
        email: 'demo@marriott.com',
        password: 'demo123'
      });
      onClose();
    } catch (error) {
      console.error('Demo login error:', error);
    }
  };

  return (
    <AnimatePresence>
      <ModalOverlay
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      >
        <ModalContainer
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
        >
          <CloseButton
            onClick={onClose}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <X size={20} />
          </CloseButton>

          <ModalHeader>
            <Logo>M</Logo>
            <Title>
              {isLogin ? 'Welcome Back' : 'Create Account'}
            </Title>
            <Subtitle>
              {isLogin 
                ? 'Sign in to your Odyssey 360 AI account' 
                : 'Join the future of hospitality'
              }
            </Subtitle>
          </ModalHeader>

          <Form onSubmit={handleSubmit}>
            <DemoButton
              type="button"
              onClick={handleDemoLogin}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Try Demo Mode
            </DemoButton>

            {!isLogin && (
              <>
                <InputGroup>
                  <InputIcon>
                    <User size={16} />
                  </InputIcon>
                  <Input
                    type="text"
                    name="firstName"
                    placeholder="First Name"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    required={!isLogin}
                  />
                </InputGroup>

                <InputGroup>
                  <InputIcon>
                    <User size={16} />
                  </InputIcon>
                  <Input
                    type="text"
                    name="lastName"
                    placeholder="Last Name"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    required={!isLogin}
                  />
                </InputGroup>
              </>
            )}

            <InputGroup>
              <InputIcon>
                <Mail size={16} />
              </InputIcon>
              <Input
                type="email"
                name="email"
                placeholder="Email Address"
                value={formData.email}
                onChange={handleInputChange}
                required
              />
            </InputGroup>

            <InputGroup>
              <InputIcon>
                <Lock size={16} />
              </InputIcon>
              <Input
                type={showPassword ? 'text' : 'password'}
                name="password"
                placeholder="Password"
                value={formData.password}
                onChange={handleInputChange}
                required
              />
              <PasswordToggle
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </PasswordToggle>
            </InputGroup>

            <Button
              type="submit"
              disabled={isLoggingIn || isRegistering}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {isLoggingIn || isRegistering ? 'Please wait...' : (isLogin ? 'Sign In' : 'Create Account')}
            </Button>
          </Form>

          <ToggleMode>
            <span style={{ color: 'var(--text-secondary)' }}>
              {isLogin ? "Don't have an account? " : "Already have an account? "}
            </span>
            <ToggleButton onClick={() => setIsLogin(!isLogin)}>
              {isLogin ? 'Sign Up' : 'Sign In'}
            </ToggleButton>
          </ToggleMode>
        </ModalContainer>
      </ModalOverlay>
    </AnimatePresence>
  );
};

export default LoginModal;
