import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { 
  Menu, 
  Bell, 
  Settings, 
  User, 
  LogIn, 
  LogOut, 
  Sun, 
  Moon,
  Wifi,
  Battery,
  Signal
} from 'lucide-react';

const HeaderContainer = styled.header`
  background: ${props => props.theme.cardBackground};
  border-bottom: 1px solid ${props => props.theme.border};
  padding: 1rem 2rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: sticky;
  top: 0;
  z-index: 100;
  backdrop-filter: blur(10px);
  box-shadow: ${props => props.theme.shadowSoft};

  @media (max-width: 768px) {
    padding: 1rem;
  }
`;

const LeftSection = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`;

const MenuButton = styled(motion.button)`
  background: none;
  border: none;
  color: ${props => props.theme.text};
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.theme.hoverBackground};
  }
`;

const Logo = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1.5rem;
  font-weight: 700;
  color: ${props => props.theme.primary};
  cursor: pointer;

  .logo-icon {
    width: 32px;
    height: 32px;
    background: ${props => props.theme.gradient};
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
  }
`;

const CenterSection = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  flex: 1;
  justify-content: center;

  @media (max-width: 768px) {
    display: none;
  }
`;

const StatusIndicator = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  background: ${props => props.theme.success}20;
  color: ${props => props.theme.success};
  border-radius: 20px;
  font-size: 0.875rem;
  font-weight: 500;

  .status-dot {
    width: 8px;
    height: 8px;
    background: ${props => props.theme.success};
    border-radius: 50%;
    animation: pulse 2s infinite;
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }
`;

const RightSection = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`;

const ActionButton = styled(motion.button)`
  background: none;
  border: none;
  color: ${props => props.theme.text};
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: ${props => props.theme.transition};
  position: relative;

  &:hover {
    background: ${props => props.theme.hoverBackground};
  }

  .notification-badge {
    position: absolute;
    top: 0;
    right: 0;
    background: ${props => props.theme.error};
    color: white;
    border-radius: 50%;
    width: 18px;
    height: 18px;
    font-size: 0.75rem;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
  }
`;

const UserMenu = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  background: ${props => props.theme.hoverBackground};
  border-radius: 12px;
  cursor: pointer;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.theme.border};
  }

  .user-avatar {
    width: 32px;
    height: 32px;
    background: ${props => props.theme.gradient};
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 600;
  }

  .user-info {
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    .user-name {
      font-weight: 600;
      font-size: 0.875rem;
    }

    .user-role {
      font-size: 0.75rem;
      color: ${props => props.theme.textSecondary};
    }
  }
`;

const ThemeToggle = styled(motion.button)`
  background: none;
  border: none;
  color: ${props => props.theme.text};
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.theme.hoverBackground};
  }
`;

const Header = ({ 
  onMenuClick, 
  onLoginClick, 
  onLogoutClick, 
  isAuthenticated, 
  user, 
  onThemeToggle 
}) => {
  const [notifications] = useState(3); // Mock notification count

  return (
    <HeaderContainer>
      <LeftSection>
        <MenuButton
          onClick={onMenuClick}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Menu size={24} />
        </MenuButton>
        
        <Logo>
          <div className="logo-icon">M</div>
          <span>Odyssey 360 AI</span>
        </Logo>
      </LeftSection>

      <CenterSection>
        <StatusIndicator>
          <div className="status-dot" />
          <span>AI Concierge Active</span>
        </StatusIndicator>
      </CenterSection>

      <RightSection>
        <ActionButton
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Bell size={20} />
          {notifications > 0 && (
            <span className="notification-badge">{notifications}</span>
          )}
        </ActionButton>

        <ThemeToggle
          onClick={onThemeToggle}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Sun size={20} />
        </ThemeToggle>

        <ActionButton
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Settings size={20} />
        </ActionButton>

        {isAuthenticated ? (
          <UserMenu onClick={onLogoutClick}>
            <div className="user-avatar">
              {user?.first_name?.charAt(0) || 'U'}
            </div>
            <div className="user-info">
              <div className="user-name">
                {user?.first_name} {user?.last_name}
              </div>
              <div className="user-role">Guest</div>
            </div>
          </UserMenu>
        ) : (
          <ActionButton
            onClick={onLoginClick}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <LogIn size={20} />
          </ActionButton>
        )}
      </RightSection>
    </HeaderContainer>
  );
};

export default Header;
