import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { 
  Heart, 
  Activity, 
  Moon, 
  Wind, 
  Droplets, 
  Thermometer,
  Calendar,
  Clock,
  Star,
  TrendingUp,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';

const WellnessContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`;

const Header = styled.div`
  background: ${props => props.theme.cardBackground};
  padding: 2rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  margin-bottom: 2rem;
  text-align: center;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme.text};
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
`;

const Subtitle = styled.p`
  color: ${props => props.theme.textSecondary};
  font-size: 1.125rem;
`;

const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`;

const StatCard = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  padding: 1.5rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  transition: ${props => props.theme.transition};

  &:hover {
    transform: translateY(-2px);
    box-shadow: ${props => props.theme.shadowMedium};
  }
`;

const StatHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1rem;
`;

const StatTitle = styled.h3`
  font-size: 0.875rem;
  font-weight: 600;
  color: ${props => props.theme.textSecondary};
  text-transform: uppercase;
  letter-spacing: 0.05em;
`;

const StatIcon = styled.div`
  width: 40px;
  height: 40px;
  background: ${props => props.color}20;
  color: ${props => props.color};
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const StatValue = styled.div`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme.text};
  margin-bottom: 0.5rem;
`;

const StatChange = styled.div`
  font-size: 0.875rem;
  color: ${props => props.positive ? props.theme.success : props.theme.error};
  display: flex;
  align-items: center;
  gap: 0.25rem;
`;

const ServicesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`;

const ServiceCard = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  padding: 1.5rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  transition: ${props => props.theme.transition};
  cursor: pointer;

  &:hover {
    transform: translateY(-2px);
    box-shadow: ${props => props.theme.shadowMedium};
  }
`;

const ServiceHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin-bottom: 1rem;
`;

const ServiceIcon = styled.div`
  width: 50px;
  height: 50px;
  background: ${props => props.theme.gradient};
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
`;

const ServiceTitle = styled.h3`
  font-size: 1.25rem;
  font-weight: 600;
  color: ${props => props.theme.text};
`;

const ServiceDescription = styled.p`
  color: ${props => props.theme.textSecondary};
  line-height: 1.6;
  margin-bottom: 1rem;
`;

const ServiceButton = styled(motion.button)`
  background: ${props => props.theme.primary};
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 500;
  cursor: pointer;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.theme.primaryDark};
    transform: translateY(-1px);
  }
`;

const AlertsSection = styled.div`
  background: ${props => props.theme.cardBackground};
  padding: 1.5rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
`;

const AlertsTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: 600;
  color: ${props => props.theme.text};
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const AlertItem = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 1rem;
  background: ${props => props.theme.hoverBackground};
  border-radius: 12px;
  margin-bottom: 0.75rem;
  border-left: 4px solid ${props => props.severity === 'high' ? props.theme.error : props.theme.warning};

  &:last-child {
    margin-bottom: 0;
  }
`;

const AlertIcon = styled.div`
  width: 32px;
  height: 32px;
  background: ${props => props.severity === 'high' ? props.theme.error : props.theme.warning}20;
  color: ${props => props.severity === 'high' ? props.theme.error : props.theme.warning};
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const AlertContent = styled.div`
  flex: 1;

  .alert-title {
    font-weight: 600;
    color: ${props => props.theme.text};
    margin-bottom: 0.25rem;
  }

  .alert-description {
    font-size: 0.875rem;
    color: ${props => props.theme.textSecondary};
  }
`;

const Wellness = () => {
  const [wellnessData] = useState({
    airQuality: {
      pm25: 12,
      pm10: 18,
      co2: 420,
      status: 'excellent'
    },
    sleepQuality: {
      score: 8.5,
      duration: '7h 32m',
      deepSleep: '2h 15m',
      remSleep: '1h 45m'
    },
    stressLevel: {
      current: 3,
      scale: '1-10',
      trend: 'decreasing'
    },
    activity: {
      steps: 8542,
      calories: 320,
      activeMinutes: 45
    }
  });

  const [alerts] = useState([
    {
      id: 1,
      title: 'Air Quality Excellent',
      description: 'Room air quality is optimal for your health and comfort.',
      severity: 'low',
      icon: CheckCircle
    },
    {
      id: 2,
      title: 'Sleep Quality Improving',
      description: 'Your sleep patterns are showing positive trends.',
      severity: 'low',
      icon: TrendingUp
    },
    {
      id: 3,
      title: 'Stress Level Normal',
      description: 'Current stress levels are within healthy range.',
      severity: 'low',
      icon: Heart
    }
  ]);

  const services = [
    {
      title: 'Spa Services',
      description: 'Book relaxing spa treatments and wellness sessions.',
      icon: Heart,
      action: 'Book Now'
    },
    {
      title: 'Fitness Classes',
      description: 'Join yoga, meditation, and fitness classes.',
      icon: Activity,
      action: 'View Classes'
    },
    {
      title: 'Sleep Optimization',
      description: 'Get personalized sleep recommendations and room adjustments.',
      icon: Moon,
      action: 'Optimize Sleep'
    },
    {
      title: 'Nutrition Guidance',
      description: 'Access healthy dining options and nutritional advice.',
      icon: Droplets,
      action: 'View Menu'
    }
  ];

  const stats = [
    {
      title: 'Air Quality',
      value: 'Excellent',
      change: '+2%',
      positive: true,
      icon: Wind,
      color: '#10B981'
    },
    {
      title: 'Sleep Score',
      value: '8.5/10',
      change: '+0.3',
      positive: true,
      icon: Moon,
      color: '#8B5CF6'
    },
    {
      title: 'Stress Level',
      value: '3/10',
      change: '-1',
      positive: true,
      icon: Heart,
      color: '#F59E0B'
    },
    {
      title: 'Activity',
      value: '8,542',
      change: '+12%',
      positive: true,
      icon: Activity,
      color: '#3B82F6'
    }
  ];

  return (
    <WellnessContainer>
      <Header>
        <Title>
          <Heart size={32} />
          Wellness & Safety
        </Title>
        <Subtitle>
          Monitor your health and wellness with intelligent insights
        </Subtitle>
      </Header>

      <StatsGrid>
        {stats.map((stat, index) => (
          <StatCard
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
          >
            <StatHeader>
              <StatTitle>{stat.title}</StatTitle>
              <StatIcon color={stat.color}>
                <stat.icon size={20} />
              </StatIcon>
            </StatHeader>
            <StatValue>{stat.value}</StatValue>
            <StatChange positive={stat.positive}>
              <TrendingUp size={16} />
              {stat.change}
            </StatChange>
          </StatCard>
        ))}
      </StatsGrid>

      <ServicesGrid>
        {services.map((service, index) => (
          <ServiceCard
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            whileHover={{ scale: 1.02 }}
          >
            <ServiceHeader>
              <ServiceIcon>
                <service.icon size={24} />
              </ServiceIcon>
              <ServiceTitle>{service.title}</ServiceTitle>
            </ServiceHeader>
            <ServiceDescription>{service.description}</ServiceDescription>
            <ServiceButton
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {service.action}
            </ServiceButton>
          </ServiceCard>
        ))}
      </ServicesGrid>

      <AlertsSection>
        <AlertsTitle>
          <AlertTriangle size={24} />
          Wellness Alerts & Recommendations
        </AlertsTitle>
        {alerts.map((alert) => (
          <AlertItem key={alert.id} severity={alert.severity}>
            <AlertIcon severity={alert.severity}>
              <alert.icon size={16} />
            </AlertIcon>
            <AlertContent>
              <div className="alert-title">{alert.title}</div>
              <div className="alert-description">{alert.description}</div>
            </AlertContent>
          </AlertItem>
        ))}
      </AlertsSection>
    </WellnessContainer>
  );
};

export default Wellness;
