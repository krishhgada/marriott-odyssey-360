import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { 
  Settings as SettingsIcon, 
  User, 
  Bell, 
  Shield, 
  Palette,
  Globe,
  Mic,
  Camera,
  Eye,
  Volume2,
  Wifi,
  Smartphone,
  Moon,
  Sun
} from 'lucide-react';

const SettingsContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`;

const Header = styled.div`
  background: ${props => props.theme.cardBackground};
  padding: 2rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  margin-bottom: 2rem;
  text-align: center;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme.text};
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
`;

const Subtitle = styled.p`
  color: ${props => props.theme.textSecondary};
  font-size: 1.125rem;
`;

const SettingsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: 1.5rem;
`;

const SettingsCard = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  padding: 1.5rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  transition: ${props => props.theme.transition};

  &:hover {
    transform: translateY(-2px);
    box-shadow: ${props => props.theme.shadowMedium};
  }
`;

const CardHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin-bottom: 1.5rem;
`;

const CardIcon = styled.div`
  width: 40px;
  height: 40px;
  background: ${props => props.theme.gradient};
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
`;

const CardTitle = styled.h3`
  font-size: 1.25rem;
  font-weight: 600;
  color: ${props => props.theme.text};
`;

const SettingItem = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 0;
  border-bottom: 1px solid ${props => props.theme.border};

  &:last-child {
    border-bottom: none;
  }
`;

const SettingInfo = styled.div`
  flex: 1;

  .setting-name {
    font-weight: 500;
    color: ${props => props.theme.text};
    margin-bottom: 0.25rem;
  }

  .setting-description {
    font-size: 0.875rem;
    color: ${props => props.theme.textSecondary};
  }
`;

const ToggleSwitch = styled(motion.button)`
  width: 60px;
  height: 30px;
  background: ${props => props.active ? props.theme.primary : props.theme.border};
  border: none;
  border-radius: 15px;
  position: relative;
  cursor: pointer;
  transition: ${props => props.theme.transition};

  &::after {
    content: '';
    position: absolute;
    top: 3px;
    left: ${props => props.active ? '33px' : '3px'};
    width: 24px;
    height: 24px;
    background: white;
    border-radius: 50%;
    transition: ${props => props.theme.transition};
  }
`;

const Select = styled.select`
  padding: 0.5rem 1rem;
  border: 1px solid ${props => props.theme.border};
  border-radius: 8px;
  background: ${props => props.theme.background};
  color: ${props => props.theme.text};
  font-size: 0.875rem;
  cursor: pointer;
  transition: ${props => props.theme.transition};

  &:focus {
    outline: none;
    border-color: ${props => props.theme.primary};
    box-shadow: 0 0 0 3px ${props => props.theme.primary}20;
  }
`;

const Slider = styled.input`
  width: 100px;
  height: 6px;
  background: ${props => props.theme.border};
  border-radius: 3px;
  outline: none;
  -webkit-appearance: none;

  &::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 20px;
    height: 20px;
    background: ${props => props.theme.primary};
    border-radius: 50%;
    cursor: pointer;
  }

  &::-moz-range-thumb {
    width: 20px;
    height: 20px;
    background: ${props => props.theme.primary};
    border-radius: 50%;
    cursor: pointer;
    border: none;
  }
`;

const Settings = () => {
  const [settings, setSettings] = useState({
    profile: {
      notifications: true,
      emailUpdates: true,
      smsUpdates: false
    },
    privacy: {
      dataCollection: true,
      locationTracking: true,
      voiceRecording: false,
      faceRecognition: false
    },
    accessibility: {
      voiceControl: true,
      screenReader: false,
      highContrast: false,
      largeText: false,
      hapticFeedback: true
    },
    appearance: {
      theme: 'marriott',
      darkMode: false,
      language: 'en',
      fontSize: 'medium'
    },
    ai: {
      personality: 'friendly',
      proactiveSuggestions: true,
      emotionDetection: true,
      learningEnabled: true
    },
    room: {
      autoAdjust: true,
      voiceCommands: true,
      biometricAccess: false,
      smartLighting: true
    }
  });

  const updateSetting = (category, setting, value) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [setting]: value
      }
    }));
  };

  const settingSections = [
    {
      title: 'Profile & Notifications',
      icon: User,
      settings: [
        {
          name: 'Push Notifications',
          description: 'Receive notifications about your stay and services',
          type: 'toggle',
          value: settings.profile.notifications,
          onChange: (value) => updateSetting('profile', 'notifications', value)
        },
        {
          name: 'Email Updates',
          description: 'Get updates via email about your stay',
          type: 'toggle',
          value: settings.profile.emailUpdates,
          onChange: (value) => updateSetting('profile', 'emailUpdates', value)
        },
        {
          name: 'SMS Updates',
          description: 'Receive text message updates',
          type: 'toggle',
          value: settings.profile.smsUpdates,
          onChange: (value) => updateSetting('profile', 'smsUpdates', value)
        }
      ]
    },
    {
      title: 'Privacy & Security',
      icon: Shield,
      settings: [
        {
          name: 'Data Collection',
          description: 'Allow collection of anonymous usage data',
          type: 'toggle',
          value: settings.privacy.dataCollection,
          onChange: (value) => updateSetting('privacy', 'dataCollection', value)
        },
        {
          name: 'Location Tracking',
          description: 'Allow location tracking for personalized services',
          type: 'toggle',
          value: settings.privacy.locationTracking,
          onChange: (value) => updateSetting('privacy', 'locationTracking', value)
        },
        {
          name: 'Voice Recording',
          description: 'Allow voice commands to be processed',
          type: 'toggle',
          value: settings.privacy.voiceRecording,
          onChange: (value) => updateSetting('privacy', 'voiceRecording', value)
        },
        {
          name: 'Face Recognition',
          description: 'Enable facial recognition for room access',
          type: 'toggle',
          value: settings.privacy.faceRecognition,
          onChange: (value) => updateSetting('privacy', 'faceRecognition', value)
        }
      ]
    },
    {
      title: 'Accessibility',
      icon: Eye,
      settings: [
        {
          name: 'Voice Control',
          description: 'Enable voice commands for all features',
          type: 'toggle',
          value: settings.accessibility.voiceControl,
          onChange: (value) => updateSetting('accessibility', 'voiceControl', value)
        },
        {
          name: 'Screen Reader',
          description: 'Optimize interface for screen readers',
          type: 'toggle',
          value: settings.accessibility.screenReader,
          onChange: (value) => updateSetting('accessibility', 'screenReader', value)
        },
        {
          name: 'High Contrast',
          description: 'Use high contrast colors for better visibility',
          type: 'toggle',
          value: settings.accessibility.highContrast,
          onChange: (value) => updateSetting('accessibility', 'highContrast', value)
        },
        {
          name: 'Large Text',
          description: 'Increase text size throughout the interface',
          type: 'toggle',
          value: settings.accessibility.largeText,
          onChange: (value) => updateSetting('accessibility', 'largeText', value)
        },
        {
          name: 'Haptic Feedback',
          description: 'Enable vibration feedback for interactions',
          type: 'toggle',
          value: settings.accessibility.hapticFeedback,
          onChange: (value) => updateSetting('accessibility', 'hapticFeedback', value)
        }
      ]
    },
    {
      title: 'Appearance',
      icon: Palette,
      settings: [
        {
          name: 'Theme',
          description: 'Choose your preferred color theme',
          type: 'select',
          value: settings.appearance.theme,
          options: [
            { value: 'marriott', label: 'Marriott' },
            { value: 'light', label: 'Light' },
            { value: 'dark', label: 'Dark' }
          ],
          onChange: (value) => updateSetting('appearance', 'theme', value)
        },
        {
          name: 'Dark Mode',
          description: 'Use dark mode for better viewing in low light',
          type: 'toggle',
          value: settings.appearance.darkMode,
          onChange: (value) => updateSetting('appearance', 'darkMode', value)
        },
        {
          name: 'Language',
          description: 'Select your preferred language',
          type: 'select',
          value: settings.appearance.language,
          options: [
            { value: 'en', label: 'English' },
            { value: 'es', label: 'Español' },
            { value: 'fr', label: 'Français' },
            { value: 'de', label: 'Deutsch' },
            { value: 'zh', label: '中文' },
            { value: 'ja', label: '日本語' }
          ],
          onChange: (value) => updateSetting('appearance', 'language', value)
        },
        {
          name: 'Font Size',
          description: 'Adjust the size of text throughout the app',
          type: 'select',
          value: settings.appearance.fontSize,
          options: [
            { value: 'small', label: 'Small' },
            { value: 'medium', label: 'Medium' },
            { value: 'large', label: 'Large' }
          ],
          onChange: (value) => updateSetting('appearance', 'fontSize', value)
        }
      ]
    },
    {
      title: 'AI Preferences',
      icon: SettingsIcon,
      settings: [
        {
          name: 'AI Personality',
          description: 'Choose your preferred AI concierge personality',
          type: 'select',
          value: settings.ai.personality,
          options: [
            { value: 'professional', label: 'Professional' },
            { value: 'friendly', label: 'Friendly' },
            { value: 'enthusiastic', label: 'Enthusiastic' },
            { value: 'calm', label: 'Calm' },
            { value: 'humorous', label: 'Humorous' },
            { value: 'empathetic', label: 'Empathetic' }
          ],
          onChange: (value) => updateSetting('ai', 'personality', value)
        },
        {
          name: 'Proactive Suggestions',
          description: 'Allow AI to make proactive recommendations',
          type: 'toggle',
          value: settings.ai.proactiveSuggestions,
          onChange: (value) => updateSetting('ai', 'proactiveSuggestions', value)
        },
        {
          name: 'Emotion Detection',
          description: 'Enable emotion detection for personalized service',
          type: 'toggle',
          value: settings.ai.emotionDetection,
          onChange: (value) => updateSetting('ai', 'emotionDetection', value)
        },
        {
          name: 'Learning Enabled',
          description: 'Allow AI to learn from your preferences',
          type: 'toggle',
          value: settings.ai.learningEnabled,
          onChange: (value) => updateSetting('ai', 'learningEnabled', value)
        }
      ]
    },
    {
      title: 'Room Controls',
      icon: Smartphone,
      settings: [
        {
          name: 'Auto Adjust',
          description: 'Automatically adjust room settings based on preferences',
          type: 'toggle',
          value: settings.room.autoAdjust,
          onChange: (value) => updateSetting('room', 'autoAdjust', value)
        },
        {
          name: 'Voice Commands',
          description: 'Enable voice control for room features',
          type: 'toggle',
          value: settings.room.voiceCommands,
          onChange: (value) => updateSetting('room', 'voiceCommands', value)
        },
        {
          name: 'Biometric Access',
          description: 'Use fingerprint or face recognition for room access',
          type: 'toggle',
          value: settings.room.biometricAccess,
          onChange: (value) => updateSetting('room', 'biometricAccess', value)
        },
        {
          name: 'Smart Lighting',
          description: 'Enable intelligent lighting control',
          type: 'toggle',
          value: settings.room.smartLighting,
          onChange: (value) => updateSetting('room', 'smartLighting', value)
        }
      ]
    }
  ];

  const renderSetting = (setting) => {
    switch (setting.type) {
      case 'toggle':
        return (
          <ToggleSwitch
            active={setting.value}
            onClick={() => setting.onChange(!setting.value)}
            whileTap={{ scale: 0.95 }}
          />
        );
      case 'select':
        return (
          <Select
            value={setting.value}
            onChange={(e) => setting.onChange(e.target.value)}
          >
            {setting.options.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </Select>
        );
      case 'slider':
        return (
          <Slider
            type="range"
            min={setting.min}
            max={setting.max}
            value={setting.value}
            onChange={(e) => setting.onChange(parseInt(e.target.value))}
          />
        );
      default:
        return null;
    }
  };

  return (
    <SettingsContainer>
      <Header>
        <Title>
          <SettingsIcon size={32} />
          Settings
        </Title>
        <Subtitle>
          Customize your Odyssey 360 AI experience
        </Subtitle>
      </Header>

      <SettingsGrid>
        {settingSections.map((section, sectionIndex) => (
          <SettingsCard
            key={sectionIndex}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: sectionIndex * 0.1 }}
          >
            <CardHeader>
              <CardIcon>
                <section.icon size={20} />
              </CardIcon>
              <CardTitle>{section.title}</CardTitle>
            </CardHeader>
            
            {section.settings.map((setting, settingIndex) => (
              <SettingItem key={settingIndex}>
                <SettingInfo>
                  <div className="setting-name">{setting.name}</div>
                  <div className="setting-description">{setting.description}</div>
                </SettingInfo>
                {renderSetting(setting)}
              </SettingItem>
            ))}
          </SettingsCard>
        ))}
      </SettingsGrid>
    </SettingsContainer>
  );
};

export default Settings;
