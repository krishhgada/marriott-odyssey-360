import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { 
  MapPin, 
  Star, 
  Clock, 
  DollarSign, 
  Navigation,
  Camera,
  Heart,
  Calendar,
  Phone,
  ExternalLink,
  Filter,
  Search
} from 'lucide-react';

const LocalDiscoveryContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`;

const Header = styled.div`
  background: ${props => props.theme.cardBackground};
  padding: 2rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  margin-bottom: 2rem;
  text-align: center;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme.text};
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
`;

const Subtitle = styled.p`
  color: ${props => props.theme.textSecondary};
  font-size: 1.125rem;
`;

const SearchSection = styled.div`
  background: ${props => props.theme.cardBackground};
  padding: 1.5rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  margin-bottom: 2rem;
`;

const SearchBar = styled.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 1rem;

  @media (max-width: 768px) {
    flex-direction: column;
  }
`;

const SearchInput = styled.input`
  flex: 1;
  padding: 0.75rem 1rem;
  border: 1px solid ${props => props.theme.border};
  border-radius: 12px;
  background: ${props => props.theme.background};
  color: ${props => props.theme.text};
  font-size: 0.875rem;
  transition: ${props => props.theme.transition};

  &:focus {
    outline: none;
    border-color: ${props => props.theme.primary};
    box-shadow: 0 0 0 3px ${props => props.theme.primary}20;
  }

  &::placeholder {
    color: ${props => props.theme.textSecondary};
  }
`;

const FilterButton = styled(motion.button)`
  background: ${props => props.theme.hoverBackground};
  color: ${props => props.theme.text};
  border: 1px solid ${props => props.theme.border};
  padding: 0.75rem 1rem;
  border-radius: 12px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.theme.primary};
    color: white;
    border-color: ${props => props.theme.primary};
  }
`;

const CategoryTabs = styled.div`
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
`;

const CategoryTab = styled(motion.button)`
  background: ${props => props.active ? props.theme.primary : props.theme.hoverBackground};
  color: ${props => props.active ? 'white' : props.theme.text};
  border: 1px solid ${props => props.active ? props.theme.primary : props.theme.border};
  padding: 0.5rem 1rem;
  border-radius: 20px;
  cursor: pointer;
  font-size: 0.875rem;
  font-weight: 500;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.theme.primary};
    color: white;
    border-color: ${props => props.theme.primary};
  }
`;

const ResultsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`;

const ResultCard = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  overflow: hidden;
  transition: ${props => props.theme.transition};
  cursor: pointer;

  &:hover {
    transform: translateY(-4px);
    box-shadow: ${props => props.theme.shadowMedium};
  }
`;

const CardImage = styled.div`
  height: 200px;
  background: ${props => props.theme.gradient};
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 3rem;
  position: relative;
`;

const CardContent = styled.div`
  padding: 1.5rem;
`;

const CardHeader = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: 1rem;
`;

const CardTitle = styled.h3`
  font-size: 1.25rem;
  font-weight: 600;
  color: ${props => props.theme.text};
  margin-bottom: 0.25rem;
`;

const CardRating = styled.div`
  display: flex;
  align-items: center;
  gap: 0.25rem;
  color: ${props => props.theme.warning};
  font-weight: 600;
`;

const CardDescription = styled.p`
  color: ${props => props.theme.textSecondary};
  line-height: 1.6;
  margin-bottom: 1rem;
`;

const CardDetails = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1rem;
  font-size: 0.875rem;
  color: ${props => props.theme.textSecondary};
`;

const CardActions = styled.div`
  display: flex;
  gap: 0.5rem;
`;

const ActionButton = styled(motion.button)`
  background: ${props => props.primary ? props.theme.primary : props.theme.hoverBackground};
  color: ${props => props.primary ? 'white' : props.theme.text};
  border: 1px solid ${props => props.primary ? props.theme.primary : props.theme.border};
  padding: 0.5rem 1rem;
  border-radius: 8px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.875rem;
  font-weight: 500;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.primary ? props.theme.primaryDark : props.theme.border};
  }
`;

const ARSection = styled.div`
  background: ${props => props.theme.cardBackground};
  padding: 2rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  text-align: center;
`;

const ARTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: 600;
  color: ${props => props.theme.text};
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
`;

const ARDescription = styled.p`
  color: ${props => props.theme.textSecondary};
  margin-bottom: 1.5rem;
`;

const ARButton = styled(motion.button)`
  background: ${props => props.theme.gradient};
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin: 0 auto;
  transition: ${props => props.theme.transition};

  &:hover {
    transform: translateY(-2px);
    box-shadow: ${props => props.theme.shadowMedium};
  }
`;

const LocalDiscovery = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    { id: 'all', name: 'All' },
    { id: 'restaurants', name: 'Restaurants' },
    { id: 'attractions', name: 'Attractions' },
    { id: 'shopping', name: 'Shopping' },
    { id: 'entertainment', name: 'Entertainment' },
    { id: 'wellness', name: 'Wellness' }
  ];

  const results = [
    {
      id: 1,
      name: 'Central Park',
      category: 'attractions',
      rating: 4.8,
      distance: '0.8 miles',
      price: 'Free',
      hours: '6:00 AM - 1:00 AM',
      description: 'Beautiful urban park perfect for walking and relaxation',
      arEnabled: true,
      image: '🌳'
    },
    {
      id: 2,
      name: 'Le Bernardin',
      category: 'restaurants',
      rating: 4.9,
      distance: '0.3 miles',
      price: '$$$$',
      hours: '5:30 PM - 10:00 PM',
      description: 'Michelin-starred French seafood restaurant',
      arEnabled: true,
      image: '🍽️'
    },
    {
      id: 3,
      name: 'Times Square',
      category: 'entertainment',
      rating: 4.2,
      distance: '0.5 miles',
      price: 'Free',
      hours: '24/7',
      description: 'Iconic entertainment district with bright lights and shows',
      arEnabled: true,
      image: '🎭'
    },
    {
      id: 4,
      name: 'Metropolitan Museum',
      category: 'attractions',
      rating: 4.6,
      distance: '1.2 miles',
      price: '$25',
      hours: '10:00 AM - 5:00 PM',
      description: 'World-renowned art museum with extensive collections',
      arEnabled: true,
      image: '🎨'
    }
  ];

  const filteredResults = results.filter(result => {
    const matchesCategory = selectedCategory === 'all' || result.category === selectedCategory;
    const matchesSearch = result.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         result.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <LocalDiscoveryContainer>
      <Header>
        <Title>
          <MapPin size={32} />
          Local Discovery
        </Title>
        <Subtitle>
          Explore the city with AI-powered recommendations and AR experiences
        </Subtitle>
      </Header>

      <SearchSection>
        <SearchBar>
          <SearchInput
            type="text"
            placeholder="Search for restaurants, attractions, or activities..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <FilterButton
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Filter size={16} />
            Filters
          </FilterButton>
        </SearchBar>
        
        <CategoryTabs>
          {categories.map((category) => (
            <CategoryTab
              key={category.id}
              active={selectedCategory === category.id}
              onClick={() => setSelectedCategory(category.id)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {category.name}
            </CategoryTab>
          ))}
        </CategoryTabs>
      </SearchSection>

      <ResultsGrid>
        {filteredResults.map((result, index) => (
          <ResultCard
            key={result.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            whileHover={{ scale: 1.02 }}
          >
            <CardImage>
              {result.image}
              {result.arEnabled && (
                <div style={{
                  position: 'absolute',
                  top: '1rem',
                  right: '1rem',
                  background: 'rgba(0,0,0,0.7)',
                  color: 'white',
                  padding: '0.25rem 0.5rem',
                  borderRadius: '12px',
                  fontSize: '0.75rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.25rem'
                }}>
                  <Camera size={12} />
                  AR
                </div>
              )}
            </CardImage>
            
            <CardContent>
              <CardHeader>
                <div>
                  <CardTitle>{result.name}</CardTitle>
                  <CardRating>
                    <Star size={16} fill="currentColor" />
                    {result.rating}
                  </CardRating>
                </div>
              </CardHeader>
              
              <CardDescription>{result.description}</CardDescription>
              
              <CardDetails>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                  <Navigation size={14} />
                  {result.distance}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                  <DollarSign size={14} />
                  {result.price}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                  <Clock size={14} />
                  {result.hours}
                </div>
              </CardDetails>
              
              <CardActions>
                <ActionButton
                  primary
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Heart size={14} />
                  Save
                </ActionButton>
                <ActionButton
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Calendar size={14} />
                  Book
                </ActionButton>
                <ActionButton
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <ExternalLink size={14} />
                  View
                </ActionButton>
              </CardActions>
            </CardContent>
          </ResultCard>
        ))}
      </ResultsGrid>

      <ARSection>
        <ARTitle>
          <Camera size={24} />
          Augmented Reality Experience
        </ARTitle>
        <ARDescription>
          Point your camera at local landmarks to see interactive information, 
          historical facts, and real-time recommendations overlaid on your view.
        </ARDescription>
        <ARButton
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Camera size={20} />
          Launch AR Experience
        </ARButton>
      </ARSection>
    </LocalDiscoveryContainer>
  );
};

export default LocalDiscovery;
