import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { Shield, Upload, Link as LinkIcon, AlertTriangle, CheckCircle, Info } from 'lucide-react';
import { useImageTrustCheck } from '../services/trustlens';

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const Header = styled.div`
  margin-bottom: 2rem;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme.text};
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const Subtitle = styled.p`
  font-size: 1rem;
  color: ${props => props.theme.textSecondary};
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  
  @media (max-width: 968px) {
    grid-template-columns: 1fr;
  }
`;

const Card = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  border: 1px solid ${props => props.theme.border};
  border-radius: 16px;
  padding: 2rem;
  box-shadow: ${props => props.theme.shadowMedium};
`;

const TabBar = styled.div`
  display: flex;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
  border-bottom: 2px solid ${props => props.theme.border};
`;

const Tab = styled.button`
  padding: 0.75rem 1.5rem;
  background: ${props => props.active ? props.theme.primary : 'transparent'};
  color: ${props => props.active ? 'white' : props.theme.textSecondary};
  border: none;
  border-bottom: 2px solid ${props => props.active ? props.theme.primary : 'transparent'};
  margin-bottom: -2px;
  cursor: pointer;
  font-weight: 600;
  transition: ${props => props.theme.transition};
  border-radius: 8px 8px 0 0;
  
  &:hover {
    background: ${props => props.active ? props.theme.primary : props.theme.hoverBackground};
    color: ${props => props.active ? 'white' : props.theme.text};
  }
`;

const FormGroup = styled.div`
  margin-bottom: 1.5rem;
`;

const Label = styled.label`
  display: block;
  font-weight: 600;
  color: ${props => props.theme.text};
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
`;

const Input = styled.input`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid ${props => props.theme.border};
  border-radius: 8px;
  background: ${props => props.theme.background};
  color: ${props => props.theme.text};
  font-size: 1rem;
  transition: ${props => props.theme.transition};
  
  &:focus {
    outline: none;
    border-color: ${props => props.theme.primary};
    box-shadow: 0 0 0 3px ${props => props.theme.primary}20;
  }
`;

const FileUploadZone = styled.div`
  border: 2px dashed ${props => props.theme.border};
  border-radius: 8px;
  padding: 2rem;
  text-align: center;
  cursor: pointer;
  transition: ${props => props.theme.transition};
  background: ${props => props.theme.background};
  
  &:hover {
    border-color: ${props => props.theme.primary};
    background: ${props => props.theme.primary}10;
  }
`;

const FileInput = styled.input`
  display: none;
`;

const UploadIcon = styled.div`
  width: 60px;
  height: 60px;
  margin: 0 auto 1rem;
  border-radius: 12px;
  background: ${props => props.theme.primary}20;
  color: ${props => props.theme.primary};
  display: flex;
  align-items: center;
  justify-content: center;
`;

const Button = styled(motion.button)`
  width: 100%;
  padding: 1rem;
  background: ${props => props.theme.gradient};
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: ${props => props.theme.transition};
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

const ScoreMeter = styled.div`
  position: relative;
  height: 200px;
  width: 200px;
  margin: 0 auto 2rem;
`;

const ScoreCircle = styled.svg`
  transform: rotate(-90deg);
`;

const ScoreBackground = styled.circle`
  fill: none;
  stroke: ${props => props.theme.border};
  stroke-width: 20;
`;

const ScoreFill = styled.circle`
  fill: none;
  stroke: ${props => 
    props.score >= 80 ? props.theme.success :
    props.score >= 60 ? props.theme.warning || '#FFA500' :
    props.theme.error
  };
  stroke-width: 20;
  stroke-linecap: round;
  stroke-dasharray: ${props => {
    const circumference = 2 * Math.PI * 80;
    const dash = (props.score / 100) * circumference;
    return `${dash} ${circumference}`;
  }};
  transition: stroke-dasharray 1s ease-in-out;
`;

const ScoreText = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
`;

const ScoreValue = styled.div`
  font-size: 3rem;
  font-weight: 700;
  color: ${props => 
    props.score >= 80 ? props.theme.success :
    props.score >= 60 ? props.theme.warning || '#FFA500' :
    props.theme.error
  };
`;

const ScoreLabel = styled.div`
  font-size: 0.875rem;
  color: ${props => props.theme.textSecondary};
  font-weight: 600;
  text-transform: uppercase;
`;

const Section = styled.div`
  margin-bottom: 2rem;
  
  &:last-child {
    margin-bottom: 0;
  }
`;

const SectionTitle = styled.h4`
  font-size: 1rem;
  font-weight: 600;
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const ItemList = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0;
`;

const ListItem = styled.li`
  padding: 0.75rem 1rem;
  background: ${props => props.theme.background};
  border: 1px solid ${props => props.theme.border};
  border-radius: 8px;
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
  color: ${props => props.theme.textSecondary};
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  
  &:last-child {
    margin-bottom: 0;
  }
`;

const TrustLens = () => {
  const [activeTab, setActiveTab] = useState('url'); // 'url' or 'file'
  const [imageUrl, setImageUrl] = useState('');
  const [fileName, setFileName] = useState('');
  const [fileData, setFileData] = useState(null);
  const [result, setResult] = useState(null);
  
  const trustCheckMutation = useImageTrustCheck();

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFileName(file.name);
      
      // Convert to base64
      const reader = new FileReader();
      reader.onloadend = () => {
        setFileData(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const requestData = {
      metadata: {
        camera: "Unknown",
        created: "2024-01-01",
        modified: "2024-01-01"
      }
    };
    
    if (activeTab === 'url') {
      if (!imageUrl) return;
      requestData.image_url = imageUrl;
      requestData.filename = imageUrl.split('/').pop();
    } else {
      if (!fileData) return;
      requestData.base64 = fileData;
      requestData.filename = fileName;
    }
    
    try {
      const response = await trustCheckMutation.mutateAsync(requestData);
      setResult(response);
    } catch (error) {
      console.error('Trust check error:', error);
    }
  };

  return (
    <Container>
      <Header>
        <Title>
          <Shield size={32} />
          TrustLens - Content Authenticity
        </Title>
        <Subtitle>
          Verify image authenticity and check for potential manipulation
        </Subtitle>
      </Header>

      <Grid>
        <Card
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h3 style={{ marginBottom: '1.5rem', fontSize: '1.25rem' }}>Upload Image</h3>
          
          <TabBar>
            <Tab active={activeTab === 'url'} onClick={() => setActiveTab('url')}>
              <LinkIcon size={16} style={{ display: 'inline', marginRight: '0.5rem' }} />
              Image URL
            </Tab>
            <Tab active={activeTab === 'file'} onClick={() => setActiveTab('file')}>
              <Upload size={16} style={{ display: 'inline', marginRight: '0.5rem' }} />
              Upload File
            </Tab>
          </TabBar>

          <form onSubmit={handleSubmit}>
            {activeTab === 'url' ? (
              <FormGroup>
                <Label>Image URL</Label>
                <Input
                  type="url"
                  placeholder="https://example.com/image.jpg"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                />
              </FormGroup>
            ) : (
              <FormGroup>
                <Label>Select Image File</Label>
                <FileUploadZone onClick={() => document.getElementById('file-input').click()}>
                  <UploadIcon>
                    <Upload size={28} />
                  </UploadIcon>
                  <div style={{ fontWeight: 600, marginBottom: '0.5rem' }}>
                    {fileName || 'Click to upload image'}
                  </div>
                  <div style={{ fontSize: '0.875rem', color: 'inherit', opacity: 0.7 }}>
                    Supports JPG, PNG, WebP
                  </div>
                </FileUploadZone>
                <FileInput
                  id="file-input"
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                />
              </FormGroup>
            )}

            <Button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              disabled={trustCheckMutation.isLoading || (activeTab === 'url' ? !imageUrl : !fileData)}
            >
              {trustCheckMutation.isLoading ? 'Analyzing...' : 'Check Authenticity'}
            </Button>
          </form>
        </Card>

        {result && (
          <Card
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <ScoreMeter>
              <ScoreCircle width="200" height="200">
                <ScoreBackground
                  cx="100"
                  cy="100"
                  r="80"
                />
                <ScoreFill
                  cx="100"
                  cy="100"
                  r="80"
                  score={result.trust_score}
                />
              </ScoreCircle>
              <ScoreText>
                <ScoreValue score={result.trust_score}>{result.trust_score}</ScoreValue>
                <ScoreLabel>Trust Score</ScoreLabel>
              </ScoreText>
            </ScoreMeter>

            <Section>
              <SectionTitle>
                <AlertTriangle size={18} />
                Detected Risks
              </SectionTitle>
              <ItemList>
                {result.risks.map((risk, index) => (
                  <ListItem key={index}>
                    <AlertTriangle size={16} style={{ flexShrink: 0, marginTop: '2px' }} />
                    <span>{risk}</span>
                  </ListItem>
                ))}
              </ItemList>
            </Section>

            <Section>
              <SectionTitle>
                <CheckCircle size={18} />
                Recommendations
              </SectionTitle>
              <ItemList>
                {result.remediation.map((item, index) => (
                  <ListItem key={index}>
                    <Info size={16} style={{ flexShrink: 0, marginTop: '2px' }} />
                    <span>{item}</span>
                  </ListItem>
                ))}
              </ItemList>
            </Section>
          </Card>
        )}
      </Grid>
    </Container>
  );
};

export default TrustLens;


