import React from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { Activity, TrendingUp } from 'lucide-react';
import { useMetrics } from '../services/analytics';

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`;

const StatCard = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  border: 1px solid ${props => props.theme.border};
  border-radius: 12px;
  padding: 1.5rem;
`;

const StatValue = styled.div`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme.primary};
  margin-bottom: 0.5rem;
`;

const StatLabel = styled.div`
  font-size: 0.875rem;
  color: ${props => props.theme.textSecondary};
  text-transform: uppercase;
  font-weight: 600;
`;

const Card = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  border: 1px solid ${props => props.theme.border};
  border-radius: 16px;
  padding: 2rem;
`;

const EventItem = styled.div`
  padding: 0.75rem;
  background: ${props => props.theme.background};
  border: 1px solid ${props => props.theme.border};
  border-radius: 8px;
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
`;

const Metrics = () => {
  const { data, isLoading } = useMetrics();

  if (isLoading) {
    return (
      <Container>
        <Title><Activity size={32} /> System Metrics</Title>
        <p>Loading metrics...</p>
      </Container>
    );
  }

  return (
    <Container>
      <Title><Activity size={32} /> System Metrics & Analytics</Title>
      
      <Grid>
        <StatCard initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <StatValue>{data?.total_events || 0}</StatValue>
          <StatLabel>Total Events</StatLabel>
        </StatCard>
        
        <StatCard initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <StatValue>{data?.counters?.status_2xx || 0}</StatValue>
          <StatLabel>Successful Requests</StatLabel>
        </StatCard>
        
        <StatCard initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <StatValue>{data?.counters?.event_api_request || 0}</StatValue>
          <StatLabel>API Requests</StatLabel>
        </StatCard>
        
        <StatCard initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <StatValue>{data?.counters?.status_4xx || 0}</StatValue>
          <StatLabel>Client Errors</StatLabel>
        </StatCard>
      </Grid>

      <Card initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
        <h3 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <TrendingUp size={20} /> Recent Events
        </h3>
        {data?.recent_events?.length > 0 ? (
          data.recent_events.map((event, idx) => (
            <EventItem key={idx}>
              <strong>{event.event_type}</strong> | {event.path} | {event.method} | 
              Status: {event.status} | {event.latency_ms}ms
              <div style={{ fontSize: '0.75rem', color: 'gray', marginTop: '0.25rem' }}>
                {event.timestamp}
              </div>
            </EventItem>
          ))
        ) : (
          <p style={{ color: 'gray' }}>No recent events</p>
        )}
      </Card>
    </Container>
  );
};

export default Metrics;


