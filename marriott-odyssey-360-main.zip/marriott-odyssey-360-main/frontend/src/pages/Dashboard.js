import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { 
  MessageCircle, 
  Home, 
  Heart, 
  MapPin, 
  Wifi, 
  Thermometer, 
  Lightbulb,
  Music,
  Bell,
  TrendingUp,
  Users,
  Star
} from 'lucide-react';

const DashboardContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`;

const WelcomeSection = styled(motion.div)`
  background: ${props => props.theme.gradient};
  color: white;
  padding: 2rem;
  border-radius: 16px;
  margin-bottom: 2rem;
  position: relative;
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
    animation: float 6s ease-in-out infinite;
  }

  @keyframes float {
    0%, 100% { transform: translateY(0px) rotate(0deg); }
    50% { transform: translateY(-20px) rotate(180deg); }
  }
`;

const WelcomeContent = styled.div`
  position: relative;
  z-index: 1;
`;

const WelcomeTitle = styled.h1`
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 0.5rem;
  background: linear-gradient(45deg, #ffffff, #f0f0f0);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;

  @media (max-width: 768px) {
    font-size: 2rem;
  }
`;

const WelcomeSubtitle = styled.p`
  font-size: 1.125rem;
  opacity: 0.9;
  margin-bottom: 1.5rem;
`;

const QuickActions = styled.div`
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;

  @media (max-width: 768px) {
    flex-direction: column;
  }
`;

const QuickActionButton = styled(motion.button)`
  background: rgba(255, 255, 255, 0.2);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: white;
  padding: 0.75rem 1.5rem;
  border-radius: 12px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 500;
  transition: all 0.3s ease;
  backdrop-filter: blur(10px);

  &:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: translateY(-2px);
  }
`;

const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`;

const StatCard = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  padding: 1.5rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  transition: ${props => props.theme.transition};

  &:hover {
    transform: translateY(-4px);
    box-shadow: ${props => props.theme.shadowMedium};
  }
`;

const StatHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1rem;
`;

const StatTitle = styled.h3`
  font-size: 0.875rem;
  font-weight: 600;
  color: ${props => props.theme.textSecondary};
  text-transform: uppercase;
  letter-spacing: 0.05em;
`;

const StatIcon = styled.div`
  width: 40px;
  height: 40px;
  background: ${props => props.color}20;
  color: ${props => props.color};
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const StatValue = styled.div`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme.text};
  margin-bottom: 0.5rem;
`;

const StatChange = styled.div`
  font-size: 0.875rem;
  color: ${props => props.positive ? props.theme.success : props.theme.error};
  display: flex;
  align-items: center;
  gap: 0.25rem;
`;

const FeaturesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`;

const FeatureCard = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  padding: 2rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  transition: ${props => props.theme.transition};
  cursor: pointer;

  &:hover {
    transform: translateY(-4px);
    box-shadow: ${props => props.theme.shadowMedium};
  }
`;

const FeatureIcon = styled.div`
  width: 60px;
  height: 60px;
  background: ${props => props.theme.gradient};
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  margin-bottom: 1rem;
`;

const FeatureTitle = styled.h3`
  font-size: 1.25rem;
  font-weight: 600;
  color: ${props => props.theme.text};
  margin-bottom: 0.75rem;
`;

const FeatureDescription = styled.p`
  color: ${props => props.theme.textSecondary};
  line-height: 1.6;
  margin-bottom: 1rem;
`;

const FeatureButton = styled(motion.button)`
  background: ${props => props.theme.primary};
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 500;
  cursor: pointer;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.theme.primaryDark};
    transform: translateY(-1px);
  }
`;

const RoomStatus = styled.div`
  background: ${props => props.theme.cardBackground};
  padding: 2rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
`;

const RoomStatusTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: 600;
  color: ${props => props.theme.text};
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const RoomControls = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
`;

const RoomControl = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem;
  background: ${props => props.theme.hoverBackground};
  border-radius: 12px;
  border: 1px solid ${props => props.theme.border};
`;

const ControlInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;

  .control-icon {
    width: 32px;
    height: 32px;
    background: ${props => props.theme.primary}20;
    color: ${props => props.theme.primary};
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .control-details {
    .control-name {
      font-weight: 500;
      color: ${props => props.theme.text};
    }

    .control-value {
      font-size: 0.875rem;
      color: ${props => props.theme.textSecondary};
    }
  }
`;

const ControlToggle = styled(motion.button)`
  width: 48px;
  height: 24px;
  background: ${props => props.active ? props.theme.primary : props.theme.border};
  border: none;
  border-radius: 12px;
  position: relative;
  cursor: pointer;
  transition: ${props => props.theme.transition};

  &::after {
    content: '';
    position: absolute;
    top: 2px;
    left: ${props => props.active ? '26px' : '2px'};
    width: 20px;
    height: 20px;
    background: white;
    border-radius: 50%;
    transition: ${props => props.theme.transition};
  }
`;

const Dashboard = () => {
  const [roomStatus, setRoomStatus] = useState({
    temperature: 72,
    lighting: 'dim',
    music: false,
    wifi: true,
    doNotDisturb: false
  });

  const stats = [
    {
      title: 'AI Interactions',
      value: '47',
      change: '+12%',
      positive: true,
      icon: MessageCircle,
      color: '#10B981'
    },
    {
      title: 'Wellness Score',
      value: '8.5',
      change: '+0.3',
      positive: true,
      icon: Heart,
      color: '#F59E0B'
    },
    {
      title: 'Local Discoveries',
      value: '12',
      change: '+3',
      positive: true,
      icon: MapPin,
      color: '#3B82F6'
    },
    {
      title: 'Satisfaction',
      value: '98%',
      change: '+2%',
      positive: true,
      icon: Star,
      color: '#8B5CF6'
    }
  ];

  const features = [
    {
      icon: MessageCircle,
      title: 'AI Concierge',
      description: 'Chat with our intelligent concierge for personalized assistance and recommendations.',
      action: 'Start Chat'
    },
    {
      icon: Heart,
      title: 'Wellness Monitoring',
      description: 'Track your wellness metrics and get personalized health and relaxation suggestions.',
      action: 'View Wellness'
    },
    {
      icon: MapPin,
      title: 'Local Discovery',
      description: 'Explore the city with AR overlays, restaurant recommendations, and local events.',
      action: 'Explore Now'
    },
    {
      icon: Home,
      title: 'Smart Room Control',
      description: 'Control your room environment with voice commands and intelligent automation.',
      action: 'Control Room'
    }
  ];

  const toggleRoomControl = (control) => {
    setRoomStatus(prev => ({
      ...prev,
      [control]: !prev[control]
    }));
  };

  return (
    <DashboardContainer>
      <WelcomeSection
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <WelcomeContent>
          <WelcomeTitle>Welcome to Odyssey 360 AI</WelcomeTitle>
          <WelcomeSubtitle>
            Your intelligent hospitality experience begins here. How can I make your stay extraordinary?
          </WelcomeSubtitle>
          <QuickActions>
            <QuickActionButton
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <MessageCircle size={20} />
              Chat with AI
            </QuickActionButton>
            <QuickActionButton
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <MapPin size={20} />
              Explore City
            </QuickActionButton>
            <QuickActionButton
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Heart size={20} />
              Wellness Check
            </QuickActionButton>
          </QuickActions>
        </WelcomeContent>
      </WelcomeSection>

      <StatsGrid>
        {stats.map((stat, index) => (
          <StatCard
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
          >
            <StatHeader>
              <StatTitle>{stat.title}</StatTitle>
              <StatIcon color={stat.color}>
                <stat.icon size={20} />
              </StatIcon>
            </StatHeader>
            <StatValue>{stat.value}</StatValue>
            <StatChange positive={stat.positive}>
              <TrendingUp size={16} />
              {stat.change}
            </StatChange>
          </StatCard>
        ))}
      </StatsGrid>

      <FeaturesGrid>
        {features.map((feature, index) => (
          <FeatureCard
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            whileHover={{ scale: 1.02 }}
          >
            <FeatureIcon>
              <feature.icon size={24} />
            </FeatureIcon>
            <FeatureTitle>{feature.title}</FeatureTitle>
            <FeatureDescription>{feature.description}</FeatureDescription>
            <FeatureButton
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {feature.action}
            </FeatureButton>
          </FeatureCard>
        ))}
      </FeaturesGrid>

      <RoomStatus>
        <RoomStatusTitle>
          <Home size={24} />
          Room 1205 - Smart Controls
        </RoomStatusTitle>
        <RoomControls>
          <RoomControl>
            <ControlInfo>
              <div className="control-icon">
                <Thermometer size={16} />
              </div>
              <div className="control-details">
                <div className="control-name">Temperature</div>
                <div className="control-value">{roomStatus.temperature}°F</div>
              </div>
            </ControlInfo>
          </RoomControl>

          <RoomControl>
            <ControlInfo>
              <div className="control-icon">
                <Lightbulb size={16} />
              </div>
              <div className="control-details">
                <div className="control-name">Lighting</div>
                <div className="control-value">{roomStatus.lighting}</div>
              </div>
            </ControlInfo>
          </RoomControl>

          <RoomControl>
            <ControlInfo>
              <div className="control-icon">
                <Music size={16} />
              </div>
              <div className="control-details">
                <div className="control-name">Music</div>
                <div className="control-value">{roomStatus.music ? 'On' : 'Off'}</div>
              </div>
            </ControlInfo>
            <ControlToggle
              active={roomStatus.music}
              onClick={() => toggleRoomControl('music')}
              whileTap={{ scale: 0.95 }}
            />
          </RoomControl>

          <RoomControl>
            <ControlInfo>
              <div className="control-icon">
                <Wifi size={16} />
              </div>
              <div className="control-details">
                <div className="control-name">WiFi</div>
                <div className="control-value">{roomStatus.wifi ? 'Connected' : 'Disconnected'}</div>
              </div>
            </ControlInfo>
            <ControlToggle
              active={roomStatus.wifi}
              onClick={() => toggleRoomControl('wifi')}
              whileTap={{ scale: 0.95 }}
            />
          </RoomControl>

          <RoomControl>
            <ControlInfo>
              <div className="control-icon">
                <Bell size={16} />
              </div>
              <div className="control-details">
                <div className="control-name">Do Not Disturb</div>
                <div className="control-value">{roomStatus.doNotDisturb ? 'Active' : 'Inactive'}</div>
              </div>
            </ControlInfo>
            <ControlToggle
              active={roomStatus.doNotDisturb}
              onClick={() => toggleRoomControl('doNotDisturb')}
              whileTap={{ scale: 0.95 }}
            />
          </RoomControl>
        </RoomControls>
      </RoomStatus>
    </DashboardContainer>
  );
};

export default Dashboard;
