import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { 
  Home, 
  Thermometer, 
  Lightbulb, 
  Music, 
  Wifi, 
  Bell, 
  Eye, 
  EyeOff,
  Volume2,
  VolumeX,
  Plus,
  Minus,
  Power
} from 'lucide-react';

const RoomControlContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`;

const Header = styled.div`
  background: ${props => props.theme.cardBackground};
  padding: 2rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  margin-bottom: 2rem;
  text-align: center;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme.text};
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
`;

const Subtitle = styled.p`
  color: ${props => props.theme.textSecondary};
  font-size: 1.125rem;
`;

const ControlsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`;

const ControlCard = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  padding: 1.5rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  transition: ${props => props.theme.transition};

  &:hover {
    transform: translateY(-2px);
    box-shadow: ${props => props.theme.shadowMedium};
  }
`;

const ControlHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin-bottom: 1rem;
`;

const ControlIcon = styled.div`
  width: 40px;
  height: 40px;
  background: ${props => props.color}20;
  color: ${props => props.color};
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const ControlTitle = styled.h3`
  font-size: 1.125rem;
  font-weight: 600;
  color: ${props => props.theme.text};
`;

const ControlContent = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1rem;
`;

const ControlValue = styled.div`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme.text};
`;

const ControlActions = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const ActionButton = styled(motion.button)`
  background: ${props => props.theme.hoverBackground};
  color: ${props => props.theme.text};
  border: 1px solid ${props => props.theme.border};
  width: 36px;
  height: 36px;
  border-radius: 8px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.theme.primary};
    color: white;
    border-color: ${props => props.theme.primary};
  }
`;

const ToggleSwitch = styled(motion.button)`
  width: 60px;
  height: 30px;
  background: ${props => props.active ? props.theme.primary : props.theme.border};
  border: none;
  border-radius: 15px;
  position: relative;
  cursor: pointer;
  transition: ${props => props.theme.transition};

  &::after {
    content: '';
    position: absolute;
    top: 3px;
    left: ${props => props.active ? '33px' : '3px'};
    width: 24px;
    height: 24px;
    background: white;
    border-radius: 50%;
    transition: ${props => props.theme.transition};
  }
`;

const Slider = styled.input`
  width: 100%;
  height: 6px;
  background: ${props => props.theme.border};
  border-radius: 3px;
  outline: none;
  -webkit-appearance: none;

  &::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 20px;
    height: 20px;
    background: ${props => props.theme.primary};
    border-radius: 50%;
    cursor: pointer;
  }

  &::-moz-range-thumb {
    width: 20px;
    height: 20px;
    background: ${props => props.theme.primary};
    border-radius: 50%;
    cursor: pointer;
    border: none;
  }
`;

const RoomControl = () => {
  const [controls, setControls] = useState({
    temperature: 72,
    lighting: 75,
    music: {
      enabled: false,
      volume: 50,
      playing: false
    },
    wifi: true,
    doNotDisturb: false,
    curtains: {
      open: true,
      level: 80
    }
  });

  const updateControl = (key, value) => {
    setControls(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const updateNestedControl = (key, subKey, value) => {
    setControls(prev => ({
      ...prev,
      [key]: {
        ...prev[key],
        [subKey]: value
      }
    }));
  };

  const controlCards = [
    {
      title: 'Temperature',
      icon: Thermometer,
      color: '#F59E0B',
      value: `${controls.temperature}°F`,
      type: 'slider',
      min: 60,
      max: 80,
      current: controls.temperature,
      onChange: (value) => updateControl('temperature', value)
    },
    {
      title: 'Lighting',
      icon: Lightbulb,
      color: '#F59E0B',
      value: `${controls.lighting}%`,
      type: 'slider',
      min: 0,
      max: 100,
      current: controls.lighting,
      onChange: (value) => updateControl('lighting', value)
    },
    {
      title: 'Music',
      icon: Music,
      color: '#8B5CF6',
      value: controls.music.enabled ? (controls.music.playing ? 'Playing' : 'Paused') : 'Off',
      type: 'music',
      enabled: controls.music.enabled,
      volume: controls.music.volume,
      playing: controls.music.playing,
      onToggle: () => updateNestedControl('music', 'enabled', !controls.music.enabled),
      onPlayToggle: () => updateNestedControl('music', 'playing', !controls.music.playing),
      onVolumeChange: (value) => updateNestedControl('music', 'volume', value)
    },
    {
      title: 'WiFi',
      icon: Wifi,
      color: '#10B981',
      value: controls.wifi ? 'Connected' : 'Disconnected',
      type: 'toggle',
      enabled: controls.wifi,
      onToggle: () => updateControl('wifi', !controls.wifi)
    },
    {
      title: 'Do Not Disturb',
      icon: Bell,
      color: '#EF4444',
      value: controls.doNotDisturb ? 'Active' : 'Inactive',
      type: 'toggle',
      enabled: controls.doNotDisturb,
      onToggle: () => updateControl('doNotDisturb', !controls.doNotDisturb)
    },
    {
      title: 'Curtains',
      icon: Eye,
      color: '#3B82F6',
      value: controls.curtains.open ? `${controls.curtains.level}% Open` : 'Closed',
      type: 'curtains',
      open: controls.curtains.open,
      level: controls.curtains.level,
      onToggle: () => updateNestedControl('curtains', 'open', !controls.curtains.open),
      onLevelChange: (value) => updateNestedControl('curtains', 'level', value)
    }
  ];

  const renderControl = (control) => {
    switch (control.type) {
      case 'slider':
        return (
          <ControlContent>
            <ControlValue>{control.value}</ControlValue>
            <Slider
              type="range"
              min={control.min}
              max={control.max}
              value={control.current}
              onChange={(e) => control.onChange(parseInt(e.target.value))}
            />
          </ControlContent>
        );

      case 'toggle':
        return (
          <ControlContent>
            <ControlValue>{control.value}</ControlValue>
            <ToggleSwitch
              active={control.enabled}
              onClick={control.onToggle}
              whileTap={{ scale: 0.95 }}
            />
          </ControlContent>
        );

      case 'music':
        return (
          <div>
            <ControlContent>
              <ControlValue>{control.value}</ControlValue>
              <ControlActions>
                <ActionButton
                  onClick={control.onToggle}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Power size={16} />
                </ActionButton>
                {control.enabled && (
                  <ActionButton
                    onClick={control.onPlayToggle}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {control.playing ? <VolumeX size={16} /> : <Volume2 size={16} />}
                  </ActionButton>
                )}
              </ControlActions>
            </ControlContent>
            {control.enabled && (
              <div>
                <div style={{ marginBottom: '0.5rem', fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                  Volume: {control.volume}%
                </div>
                <Slider
                  type="range"
                  min="0"
                  max="100"
                  value={control.volume}
                  onChange={(e) => control.onVolumeChange(parseInt(e.target.value))}
                />
              </div>
            )}
          </div>
        );

      case 'curtains':
        return (
          <div>
            <ControlContent>
              <ControlValue>{control.value}</ControlValue>
              <ControlActions>
                <ActionButton
                  onClick={control.onToggle}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {control.open ? <EyeOff size={16} /> : <Eye size={16} />}
                </ActionButton>
              </ControlActions>
            </ControlContent>
            {control.open && (
              <div>
                <div style={{ marginBottom: '0.5rem', fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                  Open Level: {control.level}%
                </div>
                <Slider
                  type="range"
                  min="0"
                  max="100"
                  value={control.level}
                  onChange={(e) => control.onLevelChange(parseInt(e.target.value))}
                />
              </div>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <RoomControlContainer>
      <Header>
        <Title>
          <Home size={32} />
          Smart Room Control
        </Title>
        <Subtitle>
          Control your room environment with intelligent automation
        </Subtitle>
      </Header>

      <ControlsGrid>
        {controlCards.map((control, index) => (
          <ControlCard
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            whileHover={{ scale: 1.02 }}
          >
            <ControlHeader>
              <ControlIcon color={control.color}>
                <control.icon size={20} />
              </ControlIcon>
              <ControlTitle>{control.title}</ControlTitle>
            </ControlHeader>
            {renderControl(control)}
          </ControlCard>
        ))}
      </ControlsGrid>
    </RoomControlContainer>
  );
};

export default RoomControl;
