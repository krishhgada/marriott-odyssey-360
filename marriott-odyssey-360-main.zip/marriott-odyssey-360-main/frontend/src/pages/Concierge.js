import React, { useState, useRef, useEffect } from 'react';
import styled from 'styled-components';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Send, 
  Mic, 
  MicOff, 
  Camera, 
  Smile, 
  Bot, 
  User,
  Phone,
  Video,
  MoreVertical,
  Settings,
  Volume2,
  VolumeX
} from 'lucide-react';

const ConciergeContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
  height: calc(100vh - 80px);
  display: flex;
  flex-direction: column;
`;

const Header = styled.div`
  background: ${props => props.theme.cardBackground};
  padding: 1.5rem;
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const AIInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`;

const AIAvatar = styled.div`
  width: 50px;
  height: 50px;
  background: ${props => props.theme.gradient};
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 1.25rem;
  font-weight: bold;
`;

const AIDetails = styled.div`
  .ai-name {
    font-size: 1.25rem;
    font-weight: 600;
    color: ${props => props.theme.text};
    margin-bottom: 0.25rem;
  }

  .ai-status {
    font-size: 0.875rem;
    color: ${props => props.theme.success};
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  .status-dot {
    width: 8px;
    height: 8px;
    background: ${props => props.theme.success};
    border-radius: 50%;
    animation: pulse 2s infinite;
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }
`;

const Controls = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const ControlButton = styled(motion.button)`
  background: ${props => props.active ? props.theme.primary : props.theme.hoverBackground};
  color: ${props => props.active ? 'white' : props.theme.text};
  border: none;
  padding: 0.75rem;
  border-radius: 12px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.active ? props.theme.primaryDark : props.theme.border};
  }
`;

const ChatContainer = styled.div`
  flex: 1;
  background: ${props => props.theme.cardBackground};
  border-radius: 16px;
  border: 1px solid ${props => props.theme.border};
  box-shadow: ${props => props.theme.shadowSoft};
  display: flex;
  flex-direction: column;
  overflow: hidden;
  margin-bottom: 1.5rem;
`;

const MessagesContainer = styled.div`
  flex: 1;
  padding: 1.5rem;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const Message = styled(motion.div)`
  display: flex;
  gap: 0.75rem;
  align-items: flex-start;
  ${props => props.isUser && 'flex-direction: row-reverse;'}
`;

const MessageAvatar = styled.div`
  width: 36px;
  height: 36px;
  background: ${props => props.isUser ? props.theme.primary : props.theme.gradient};
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: 600;
  flex-shrink: 0;
`;

const MessageContent = styled.div`
  max-width: 70%;
  ${props => props.isUser && 'text-align: right;'}
`;

const MessageBubble = styled.div`
  background: ${props => props.isUser ? props.theme.primary : props.theme.hoverBackground};
  color: ${props => props.isUser ? 'white' : props.theme.text};
  padding: 0.75rem 1rem;
  border-radius: 18px;
  font-size: 0.875rem;
  line-height: 1.5;
  word-wrap: break-word;
  ${props => props.isUser && 'border-bottom-right-radius: 4px;'}
  ${props => !props.isUser && 'border-bottom-left-radius: 4px;'}
`;

const MessageTime = styled.div`
  font-size: 0.75rem;
  color: ${props => props.theme.textSecondary};
  margin-top: 0.25rem;
  ${props => props.isUser && 'text-align: right;'}
`;

const Suggestions = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin-top: 1rem;
`;

const SuggestionChip = styled(motion.button)`
  background: ${props => props.theme.hoverBackground};
  color: ${props => props.theme.text};
  border: 1px solid ${props => props.theme.border};
  padding: 0.5rem 1rem;
  border-radius: 20px;
  font-size: 0.75rem;
  cursor: pointer;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.theme.primary};
    color: white;
    border-color: ${props => props.theme.primary};
  }
`;

const InputContainer = styled.div`
  padding: 1.5rem;
  border-top: 1px solid ${props => props.theme.border};
  background: ${props => props.theme.background};
`;

const InputRow = styled.div`
  display: flex;
  gap: 0.75rem;
  align-items: flex-end;
`;

const InputWrapper = styled.div`
  flex: 1;
  position: relative;
`;

const MessageInput = styled.textarea`
  width: 100%;
  min-height: 44px;
  max-height: 120px;
  padding: 0.75rem 1rem;
  border: 1px solid ${props => props.theme.border};
  border-radius: 22px;
  background: ${props => props.theme.background};
  color: ${props => props.theme.text};
  font-size: 0.875rem;
  resize: none;
  transition: ${props => props.theme.transition};

  &:focus {
    outline: none;
    border-color: ${props => props.theme.primary};
    box-shadow: 0 0 0 3px ${props => props.theme.primary}20;
  }

  &::placeholder {
    color: ${props => props.theme.textSecondary};
  }
`;

const SendButton = styled(motion.button)`
  background: ${props => props.theme.primary};
  color: white;
  border: none;
  width: 44px;
  height: 44px;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.theme.primaryDark};
    transform: scale(1.05);
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`;

const VoiceButton = styled(motion.button)`
  background: ${props => props.isRecording ? props.theme.error : props.theme.hoverBackground};
  color: ${props => props.isRecording ? 'white' : props.theme.text};
  border: none;
  width: 44px;
  height: 44px;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: ${props => props.theme.transition};

  &:hover {
    background: ${props => props.isRecording ? props.theme.error : props.theme.border};
  }
`;

const Concierge = () => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "Hello! I'm your AI Concierge. How can I make your stay extraordinary today?",
      isUser: false,
      timestamp: new Date(),
      suggestions: [
        "Room service",
        "Local recommendations",
        "Wellness services",
        "Transportation"
      ]
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const newMessage = {
      id: Date.now(),
      text: inputText,
      isUser: true,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = {
        id: Date.now() + 1,
        text: "I'd be happy to help you with that! Let me assist you with your request.",
        isUser: false,
        timestamp: new Date(),
        suggestions: [
          "Tell me more",
          "What else can you help with?",
          "Book this service",
          "Cancel"
        ]
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSuggestionClick = (suggestion) => {
    setInputText(suggestion);
  };

  const handleVoiceToggle = () => {
    setIsRecording(!isRecording);
    // Voice recording logic would go here
  };

  const quickSuggestions = [
    "Order room service",
    "Book spa appointment",
    "Find local restaurants",
    "Request housekeeping",
    "Get weather update",
    "Schedule transportation"
  ];

  return (
    <ConciergeContainer>
      <Header>
        <AIInfo>
          <AIAvatar>
            <Bot size={24} />
          </AIAvatar>
          <AIDetails>
            <div className="ai-name">AI Concierge</div>
            <div className="ai-status">
              <div className="status-dot" />
              Online & Ready to Help
            </div>
          </AIDetails>
        </AIInfo>
        
        <Controls>
          <ControlButton
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Phone size={20} />
          </ControlButton>
          <ControlButton
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Video size={20} />
          </ControlButton>
          <ControlButton
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Settings size={20} />
          </ControlButton>
        </Controls>
      </Header>

      <ChatContainer>
        <MessagesContainer>
          <AnimatePresence>
            {messages.map((message) => (
              <Message
                key={message.id}
                isUser={message.isUser}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <MessageAvatar isUser={message.isUser}>
                  {message.isUser ? <User size={16} /> : <Bot size={16} />}
                </MessageAvatar>
                <MessageContent isUser={message.isUser}>
                  <MessageBubble isUser={message.isUser}>
                    {message.text}
                  </MessageBubble>
                  <MessageTime isUser={message.isUser}>
                    {message.timestamp.toLocaleTimeString()}
                  </MessageTime>
                  {message.suggestions && (
                    <Suggestions>
                      {message.suggestions.map((suggestion, index) => (
                        <SuggestionChip
                          key={index}
                          onClick={() => handleSuggestionClick(suggestion)}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          {suggestion}
                        </SuggestionChip>
                      ))}
                    </Suggestions>
                  )}
                </MessageContent>
              </Message>
            ))}
          </AnimatePresence>
          
          {isTyping && (
            <Message isUser={false}>
              <MessageAvatar isUser={false}>
                <Bot size={16} />
              </MessageAvatar>
              <MessageContent isUser={false}>
                <MessageBubble isUser={false}>
                  <motion.div
                    animate={{ opacity: [0.5, 1, 0.5] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  >
                    AI is typing...
                  </motion.div>
                </MessageBubble>
              </MessageContent>
            </Message>
          )}
          
          <div ref={messagesEndRef} />
        </MessagesContainer>

        <InputContainer>
          <div style={{ marginBottom: '1rem' }}>
            <Suggestions>
              {quickSuggestions.map((suggestion, index) => (
                <SuggestionChip
                  key={index}
                  onClick={() => handleSuggestionClick(suggestion)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {suggestion}
                </SuggestionChip>
              ))}
            </Suggestions>
          </div>
          
          <InputRow>
            <InputWrapper>
              <MessageInput
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message or ask me anything..."
                rows={1}
              />
            </InputWrapper>
            
            <VoiceButton
              isRecording={isRecording}
              onClick={handleVoiceToggle}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {isRecording ? <MicOff size={20} /> : <Mic size={20} />}
            </VoiceButton>
            
            <SendButton
              onClick={handleSendMessage}
              disabled={!inputText.trim()}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Send size={20} />
            </SendButton>
          </InputRow>
        </InputContainer>
      </ChatContainer>
    </ConciergeContainer>
  );
};

export default Concierge;
