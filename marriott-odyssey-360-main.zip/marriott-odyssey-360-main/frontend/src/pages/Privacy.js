import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { Shield, CheckCircle, AlertTriangle, Info } from 'lucide-react';
import { usePrivacyRecommendation } from '../services/privacy';
import toast from 'react-hot-toast';

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const Header = styled.div`
  margin-bottom: 2rem;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme.text};
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const Subtitle = styled.p`
  font-size: 1rem;
  color: ${props => props.theme.textSecondary};
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  
  @media (max-width: 968px) {
    grid-template-columns: 1fr;
  }
`;

const Card = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  border: 1px solid ${props => props.theme.border};
  border-radius: 16px;
  padding: 2rem;
  box-shadow: ${props => props.theme.shadowMedium};
`;

const FormGroup = styled.div`
  margin-bottom: 1.5rem;
`;

const Label = styled.label`
  display: block;
  font-weight: 600;
  color: ${props => props.theme.text};
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
`;

const Select = styled.select`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid ${props => props.theme.border};
  border-radius: 8px;
  background: ${props => props.theme.background};
  color: ${props => props.theme.text};
  font-size: 1rem;
  cursor: pointer;
  transition: ${props => props.theme.transition};
  
  &:focus {
    outline: none;
    border-color: ${props => props.theme.primary};
    box-shadow: 0 0 0 3px ${props => props.theme.primary}20;
  }
`;

const SliderContainer = styled.div`
  padding: 0.5rem 0;
`;

const Slider = styled.input`
  width: 100%;
  height: 6px;
  border-radius: 3px;
  background: ${props => props.theme.border};
  outline: none;
  
  &::-webkit-slider-thumb {
    appearance: none;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: ${props => props.theme.primary};
    cursor: pointer;
    transition: ${props => props.theme.transition};
    
    &:hover {
      transform: scale(1.2);
    }
  }
  
  &::-moz-range-thumb {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: ${props => props.theme.primary};
    cursor: pointer;
    border: none;
  }
`;

const SliderLabels = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 0.5rem;
  font-size: 0.75rem;
  color: ${props => props.theme.textSecondary};
`;

const Button = styled(motion.button)`
  width: 100%;
  padding: 1rem;
  background: ${props => props.theme.gradient};
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: ${props => props.theme.transition};
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

const ResultCard = styled(Card)`
  ${props => props.mode === 'strict' && `border-color: ${props.theme.error};`}
  ${props => props.mode === 'perks' && `border-color: ${props.theme.success};`}
  ${props => props.mode === 'balanced' && `border-color: ${props.theme.primary};`}
`;

const ModeHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1.5rem;
`;

const ModeIcon = styled.div`
  width: 60px;
  height: 60px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
  
  ${props => props.mode === 'strict' && `
    background: ${props.theme.error}20;
    color: ${props.theme.error};
  `}
  ${props => props.mode === 'perks' && `
    background: ${props.theme.success}20;
    color: ${props.theme.success};
  `}
  ${props => props.mode === 'balanced' && `
    background: ${props.theme.primary}20;
    color: ${props.theme.primary};
  `}
`;

const ModeTitle = styled.h3`
  font-size: 1.5rem;
  font-weight: 700;
  text-transform: capitalize;
  margin-bottom: 0.25rem;
`;

const ModeSubtitle = styled.p`
  font-size: 0.875rem;
  color: ${props => props.theme.textSecondary};
`;

const TogglesGrid = styled.div`
  display: grid;
  gap: 1rem;
  margin: 1.5rem 0;
`;

const ToggleItem = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem;
  background: ${props => props.theme.background};
  border-radius: 8px;
  border: 1px solid ${props => props.theme.border};
`;

const ToggleName = styled.span`
  font-weight: 500;
  text-transform: capitalize;
`;

const ToggleStatus = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.875rem;
  color: ${props => props.enabled ? props.theme.success : props.theme.textSecondary};
  font-weight: 600;
`;

const ExplanationList = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0;
`;

const ExplanationItem = styled.li`
  padding: 0.75rem 0;
  border-bottom: 1px solid ${props => props.theme.border};
  color: ${props => props.theme.textSecondary};
  font-size: 0.875rem;
  
  &:last-child {
    border-bottom: none;
  }
  
  &:first-child {
    padding-top: 0;
  }
`;

const Privacy = () => {
  const [formData, setFormData] = useState({
    persona: 'solo',
    trip_type: 'leisure',
    risk_tolerance: 3,
  });
  
  const [result, setResult] = useState(null);
  const recommendationMutation = usePrivacyRecommendation();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await recommendationMutation.mutateAsync(formData);
      setResult(response);
    } catch (error) {
      console.error('Privacy recommendation error:', error);
    }
  };

  const handleApply = () => {
    toast.success('Privacy settings applied successfully!');
    // In a real app, this would save the settings
  };

  return (
    <Container>
      <Header>
        <Title>
          <Shield size={32} />
          Predictive Privacy Controller
        </Title>
        <Subtitle>
          Get personalized privacy recommendations based on your travel profile
        </Subtitle>
      </Header>

      <Grid>
        <Card
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h3 style={{ marginBottom: '1.5rem', fontSize: '1.25rem' }}>Your Profile</h3>
          
          <form onSubmit={handleSubmit}>
            <FormGroup>
              <Label>Travel Persona</Label>
              <Select
                value={formData.persona}
                onChange={(e) => setFormData({ ...formData, persona: e.target.value })}
              >
                <option value="business">Business Traveler</option>
                <option value="family">Family</option>
                <option value="solo">Solo Traveler</option>
              </Select>
            </FormGroup>

            <FormGroup>
              <Label>Trip Type</Label>
              <Select
                value={formData.trip_type}
                onChange={(e) => setFormData({ ...formData, trip_type: e.target.value })}
              >
                <option value="work">Work</option>
                <option value="leisure">Leisure</option>
                <option value="bleisure">Bleisure (Business + Leisure)</option>
              </Select>
            </FormGroup>

            <FormGroup>
              <Label>Privacy Risk Tolerance</Label>
              <SliderContainer>
                <Slider
                  type="range"
                  min="1"
                  max="5"
                  value={formData.risk_tolerance}
                  onChange={(e) => setFormData({ ...formData, risk_tolerance: parseInt(e.target.value) })}
                />
                <SliderLabels>
                  <span>Very Private (1)</span>
                  <span>Balanced ({formData.risk_tolerance})</span>
                  <span>Open (5)</span>
                </SliderLabels>
              </SliderContainer>
            </FormGroup>

            <Button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              disabled={recommendationMutation.isLoading}
            >
              {recommendationMutation.isLoading ? 'Analyzing...' : 'Get Recommendations'}
            </Button>
          </form>
        </Card>

        {result && (
          <ResultCard
            mode={result.mode}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <ModeHeader>
              <ModeIcon mode={result.mode}>
                {result.mode === 'strict' && <AlertTriangle size={28} />}
                {result.mode === 'perks' && <CheckCircle size={28} />}
                {result.mode === 'balanced' && <Info size={28} />}
              </ModeIcon>
              <div>
                <ModeTitle>{result.mode} Mode</ModeTitle>
                <ModeSubtitle>Recommended for your profile</ModeSubtitle>
              </div>
            </ModeHeader>

            <h4 style={{ marginBottom: '1rem', fontSize: '1rem', fontWeight: 600 }}>Privacy Toggles</h4>
            <TogglesGrid>
              {Object.entries(result.toggles).map(([key, value]) => (
                <ToggleItem key={key}>
                  <ToggleName>{key.replace('_', ' ')}</ToggleName>
                  <ToggleStatus enabled={value}>
                    {value ? <CheckCircle size={16} /> : <AlertTriangle size={16} />}
                    {value ? 'Enabled' : 'Disabled'}
                  </ToggleStatus>
                </ToggleItem>
              ))}
            </TogglesGrid>

            <h4 style={{ margin: '1.5rem 0 1rem', fontSize: '1rem', fontWeight: 600 }}>Why This Recommendation?</h4>
            <ExplanationList>
              {result.explanation.map((item, index) => (
                <ExplanationItem key={index}>{item}</ExplanationItem>
              ))}
            </ExplanationList>

            <Button
              style={{ marginTop: '1.5rem' }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleApply}
            >
              Apply These Settings
            </Button>
          </ResultCard>
        )}
      </Grid>
    </Container>
  );
};

export default Privacy;


