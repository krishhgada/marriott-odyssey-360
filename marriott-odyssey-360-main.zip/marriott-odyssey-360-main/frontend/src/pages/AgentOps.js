import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { Users, MessageSquare } from 'lucide-react';
import { usePolicyAnswer, useDraftReply } from '../services/agentops';

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  @media (max-width: 968px) { grid-template-columns: 1fr; }
`;

const Card = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  border: 1px solid ${props => props.theme.border};
  border-radius: 16px;
  padding: 2rem;
`;

const Textarea = styled.textarea`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid ${props => props.theme.border};
  border-radius: 8px;
  background: ${props => props.theme.background};
  color: ${props => props.theme.text};
  min-height: 100px;
  margin-bottom: 1rem;
  font-family: inherit;
`;

const Button = styled(motion.button)`
  width: 100%;
  padding: 1rem;
  background: ${props => props.theme.gradient};
  color: white;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
`;

const Result = styled.div`
  padding: 1rem;
  background: ${props => props.theme.background};
  border: 1px solid ${props => props.theme.border};
  border-radius: 8px;
  margin-top: 1rem;
`;

const Citation = styled.span`
  display: inline-block;
  padding: 0.25rem 0.5rem;
  background: ${props => props.theme.primary}20;
  color: ${props => props.theme.primary};
  border-radius: 4px;
  font-size: 0.75rem;
  margin: 0.25rem;
  font-weight: 600;
`;

const AgentOps = () => {
  const [question, setQuestion] = useState('');
  const [ticket, setTicket] = useState('');
  const [answer, setAnswer] = useState(null);
  const [draft, setDraft] = useState(null);

  const answerMutation = usePolicyAnswer();
  const draftMutation = useDraftReply();

  const handleAsk = async (e) => {
    e.preventDefault();
    try {
      const response = await answerMutation.mutateAsync({ question });
      setAnswer(response);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDraft = async (e) => {
    e.preventDefault();
    try {
      const response = await draftMutation.mutateAsync({ ticket_text: ticket });
      setDraft(response);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Container>
      <Title><Users size={32} /> AgentOps - Policy Assistant</Title>
      
      <Grid>
        <Card initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h3 style={{ marginBottom: '1rem' }}><MessageSquare size={20} /> Ask Policy Question</h3>
          <form onSubmit={handleAsk}>
            <Textarea
              placeholder="e.g., What is the cancellation policy?"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              required
            />
            <Button type="submit" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              {answerMutation.isLoading ? 'Searching...' : 'Get Answer'}
            </Button>
          </form>
          {answer && (
            <Result>
              <p>{answer.answer}</p>
              <div style={{ marginTop: '1rem' }}>
                {answer.citations.map((cit, idx) => (
                  <Citation key={idx}>{cit}</Citation>
                ))}
              </div>
            </Result>
          )}
        </Card>

        <Card initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <h3 style={{ marginBottom: '1rem' }}>Draft Guest Reply</h3>
          <form onSubmit={handleDraft}>
            <Textarea
              placeholder="Paste guest inquiry or complaint..."
              value={ticket}
              onChange={(e) => setTicket(e.target.value)}
              required
            />
            <Button type="submit" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              {draftMutation.isLoading ? 'Drafting...' : 'Generate Reply'}
            </Button>
          </form>
          {draft && (
            <Result>
              <p>{draft.draft}</p>
              <div style={{ marginTop: '1rem' }}>
                {draft.citations.map((cit, idx) => (
                  <Citation key={idx}>{cit}</Citation>
                ))}
              </div>
            </Result>
          )}
        </Card>
      </Grid>
    </Container>
  );
};

export default AgentOps;


