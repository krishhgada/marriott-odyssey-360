import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { Globe, Copy, CheckCircle } from 'lucide-react';
import { useCultureAdaptation } from '../services/culture';
import toast from 'react-hot-toast';

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const Header = styled.div`
  margin-bottom: 2rem;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme.text};
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const Subtitle = styled.p`
  font-size: 1rem;
  color: ${props => props.theme.textSecondary};
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  
  @media (max-width: 968px) {
    grid-template-columns: 1fr;
  }
`;

const Card = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  border: 1px solid ${props => props.theme.border};
  border-radius: 16px;
  padding: 2rem;
  box-shadow: ${props => props.theme.shadowMedium};
`;

const FormGroup = styled.div`
  margin-bottom: 1.5rem;
`;

const Label = styled.label`
  display: block;
  font-weight: 600;
  color: ${props => props.theme.text};
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
`;

const Select = styled.select`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid ${props => props.theme.border};
  border-radius: 8px;
  background: ${props => props.theme.background};
  color: ${props => props.theme.text};
  font-size: 1rem;
  cursor: pointer;
  transition: ${props => props.theme.transition};
  
  &:focus {
    outline: none;
    border-color: ${props => props.theme.primary};
    box-shadow: 0 0 0 3px ${props => props.theme.primary}20;
  }
`;

const CheckboxGroup = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.75rem;
  
  @media (max-width: 600px) {
    grid-template-columns: 1fr;
  }
`;

const CheckboxLabel = styled.label`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem;
  background: ${props => props.theme.background};
  border: 1px solid ${props => props.checked ? props.theme.primary : props.theme.border};
  border-radius: 8px;
  cursor: pointer;
  transition: ${props => props.theme.transition};
  
  &:hover {
    border-color: ${props => props.theme.primary};
    background: ${props => props.theme.primary}10;
  }
`;

const Checkbox = styled.input`
  cursor: pointer;
  width: 18px;
  height: 18px;
`;

const CheckboxText = styled.span`
  font-size: 0.875rem;
  font-weight: 500;
`;

const Button = styled(motion.button)`
  width: 100%;
  padding: 1rem;
  background: ${props => props.theme.gradient};
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: ${props => props.theme.transition};
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

const ResultSection = styled.div`
  margin-bottom: 2rem;
  
  &:last-child {
    margin-bottom: 0;
  }
`;

const SectionTitle = styled.h4`
  font-size: 1rem;
  font-weight: 600;
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const CopyButton = styled(motion.button)`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  background: ${props => props.theme.primary}20;
  color: ${props => props.theme.primary};
  border: 1px solid ${props => props.theme.primary};
  border-radius: 6px;
  font-size: 0.75rem;
  font-weight: 600;
  cursor: pointer;
  transition: ${props => props.theme.transition};
  
  &:hover {
    background: ${props => props.theme.primary};
    color: white;
  }
`;

const GreetingBox = styled.div`
  padding: 1.5rem;
  background: ${props => props.theme.gradient};
  color: white;
  border-radius: 12px;
  font-size: 1.125rem;
  font-weight: 500;
  text-align: center;
  margin-bottom: 1rem;
  box-shadow: ${props => props.theme.shadowMedium};
`;

const ItemList = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0;
`;

const ListItem = styled.li`
  padding: 0.75rem 1rem;
  background: ${props => props.theme.background};
  border: 1px solid ${props => props.theme.border};
  border-radius: 8px;
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
  color: ${props => props.theme.textSecondary};
  transition: ${props => props.theme.transition};
  
  &:hover {
    border-color: ${props => props.theme.primary};
    transform: translateX(4px);
  }
  
  &:last-child {
    margin-bottom: 0;
  }
`;

const CultureAccessibility = () => {
  const [formData, setFormData] = useState({
    language_pref: 'en',
    dietary: [],
    accessibility: [],
  });
  
  const [result, setResult] = useState(null);
  const adaptationMutation = useCultureAdaptation();

  const dietaryOptions = [
    { value: 'veg', label: 'Vegetarian' },
    { value: 'vegan', label: 'Vegan' },
    { value: 'halal', label: 'Halal' },
    { value: 'kosher', label: 'Kosher' },
    { value: 'allergen_nuts', label: 'Nut Allergy' },
    { value: 'allergen_gluten', label: 'Gluten-Free' },
    { value: 'allergen_dairy', label: 'Dairy-Free' },
  ];

  const accessibilityOptions = [
    { value: 'wheelchair', label: 'Wheelchair Access' },
    { value: 'low_vision', label: 'Low Vision' },
    { value: 'hearing', label: 'Hearing Impaired' },
    { value: 'mobility', label: 'Mobility Assistance' },
  ];

  const languageOptions = [
    { value: 'en', label: 'English' },
    { value: 'es', label: 'Español' },
    { value: 'fr', label: 'Français' },
    { value: 'de', label: 'Deutsch' },
    { value: 'it', label: 'Italiano' },
    { value: 'pt', label: 'Português' },
    { value: 'zh', label: '中文' },
    { value: 'ja', label: '日本語' },
    { value: 'ko', label: '한국어' },
    { value: 'ar', label: 'العربية' },
    { value: 'hi', label: 'हिन्दी' },
  ];

  const handleCheckbox = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter(v => v !== value)
        : [...prev[field], value]
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await adaptationMutation.mutateAsync(formData);
      setResult(response);
    } catch (error) {
      console.error('Culture adaptation error:', error);
    }
  };

  const copyToClipboard = (text, label) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard!`);
  };

  const copyAllItems = (items, label) => {
    const text = items.join('\n');
    navigator.clipboard.writeText(text);
    toast.success(`All ${label} copied to clipboard!`);
  };

  return (
    <Container>
      <Header>
        <Title>
          <Globe size={32} />
          Cultural Inclusion & Accessibility
        </Title>
        <Subtitle>
          Customize your experience based on language, dietary, and accessibility preferences
        </Subtitle>
      </Header>

      <Grid>
        <Card
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h3 style={{ marginBottom: '1.5rem', fontSize: '1.25rem' }}>Your Preferences</h3>
          
          <form onSubmit={handleSubmit}>
            <FormGroup>
              <Label>Preferred Language</Label>
              <Select
                value={formData.language_pref}
                onChange={(e) => setFormData({ ...formData, language_pref: e.target.value })}
              >
                {languageOptions.map(opt => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </Select>
            </FormGroup>

            <FormGroup>
              <Label>Dietary Restrictions</Label>
              <CheckboxGroup>
                {dietaryOptions.map(opt => (
                  <CheckboxLabel
                    key={opt.value}
                    checked={formData.dietary.includes(opt.value)}
                  >
                    <Checkbox
                      type="checkbox"
                      checked={formData.dietary.includes(opt.value)}
                      onChange={() => handleCheckbox('dietary', opt.value)}
                    />
                    <CheckboxText>{opt.label}</CheckboxText>
                  </CheckboxLabel>
                ))}
              </CheckboxGroup>
            </FormGroup>

            <FormGroup>
              <Label>Accessibility Needs</Label>
              <CheckboxGroup>
                {accessibilityOptions.map(opt => (
                  <CheckboxLabel
                    key={opt.value}
                    checked={formData.accessibility.includes(opt.value)}
                  >
                    <Checkbox
                      type="checkbox"
                      checked={formData.accessibility.includes(opt.value)}
                      onChange={() => handleCheckbox('accessibility', opt.value)}
                    />
                    <CheckboxText>{opt.label}</CheckboxText>
                  </CheckboxLabel>
                ))}
              </CheckboxGroup>
            </FormGroup>

            <Button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              disabled={adaptationMutation.isLoading}
            >
              {adaptationMutation.isLoading ? 'Generating...' : 'Get Personalized Content'}
            </Button>
          </form>
        </Card>

        {result && (
          <Card
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <ResultSection>
              <SectionTitle>
                Your Greeting
                <CopyButton
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => copyToClipboard(result.greetings_text, 'Greeting')}
                >
                  <Copy size={14} />
                  Copy
                </CopyButton>
              </SectionTitle>
              <GreetingBox>{result.greetings_text}</GreetingBox>
            </ResultSection>

            <ResultSection>
              <SectionTitle>
                Menu Highlights
                <CopyButton
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => copyAllItems(result.menu_highlights, 'menu items')}
                >
                  <Copy size={14} />
                  Copy All
                </CopyButton>
              </SectionTitle>
              <ItemList>
                {result.menu_highlights.map((item, index) => (
                  <ListItem key={index}>{item}</ListItem>
                ))}
              </ItemList>
            </ResultSection>

            <ResultSection>
              <SectionTitle>
                Room Notes
                <CopyButton
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => copyAllItems(result.room_notes, 'room notes')}
                >
                  <Copy size={14} />
                  Copy All
                </CopyButton>
              </SectionTitle>
              <ItemList>
                {result.room_notes.map((item, index) => (
                  <ListItem key={index}>{item}</ListItem>
                ))}
              </ItemList>
            </ResultSection>

            <ResultSection>
              <SectionTitle>
                Accessibility Information
                <CopyButton
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => copyAllItems(result.accessibility_hints, 'accessibility info')}
                >
                  <Copy size={14} />
                  Copy All
                </CopyButton>
              </SectionTitle>
              <ItemList>
                {result.accessibility_hints.map((item, index) => (
                  <ListItem key={index}>{item}</ListItem>
                ))}
              </ItemList>
            </ResultSection>
          </Card>
        )}
      </Grid>
    </Container>
  );
};

export default CultureAccessibility;


