import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { Heart, Zap } from 'lucide-react';
import { useInsightsPrediction } from '../services/insights';

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const Card = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  border: 1px solid ${props => props.theme.border};
  border-radius: 16px;
  padding: 2rem;
  margin-bottom: 2rem;
`;

const Label = styled.label`
  display: block;
  font-weight: 600;
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
`;

const Slider = styled.input`
  width: 100%;
  margin-bottom: 1.5rem;
`;

const Select = styled.select`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid ${props => props.theme.border};
  border-radius: 8px;
  background: ${props => props.theme.background};
  color: ${props => props.theme.text};
  margin-bottom: 1rem;
`;

const Button = styled(motion.button)`
  width: 100%;
  padding: 1rem;
  background: ${props => props.theme.gradient};
  color: white;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
`;

const StateCard = styled.div`
  padding: 1.5rem;
  background: ${props => props.theme.primary}20;
  border: 2px solid ${props => props.theme.primary};
  border-radius: 12px;
  text-align: center;
  margin-bottom: 1rem;
`;

const MoodWellness = () => {
  const [mood, setMood] = useState({
    stress_level: 0.5,
    energy_level: 0.5,
    local_weather: 'Clear'
  });
  const [result, setResult] = useState(null);
  const predictionMutation = useInsightsPrediction();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await predictionMutation.mutateAsync({
        guest_id: 'G123',
        mood,
        context: {
          time_of_day: new Date().toTimeString().slice(0, 5),
          occupancy_pct: 65
        },
        preferences: {
          likes_quiet: true,
          preferred_cuisine: 'Italian'
        }
      });
      setResult(response);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Container>
      <Title><Heart size={32} /> Mood & Wellness Insights</Title>
      
      <Card initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <form onSubmit={handleSubmit}>
          <Label>Stress Level: {(mood.stress_level * 100).toFixed(0)}%</Label>
          <Slider
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={mood.stress_level}
            onChange={(e) => setMood({...mood, stress_level: parseFloat(e.target.value)})}
          />
          
          <Label>Energy Level: {(mood.energy_level * 100).toFixed(0)}%</Label>
          <Slider
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={mood.energy_level}
            onChange={(e) => setMood({...mood, energy_level: parseFloat(e.target.value)})}
          />
          
          <Label>Current Weather</Label>
          <Select
            value={mood.local_weather}
            onChange={(e) => setMood({...mood, local_weather: e.target.value})}
          >
            <option>Clear</option>
            <option>Cloudy</option>
            <option>Rain</option>
            <option>Snow</option>
          </Select>
          
          <Button type="submit" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            {predictionMutation.isLoading ? 'Analyzing...' : 'Get Personalized Suggestion'}
          </Button>
        </form>
      </Card>

      {result && (
        <Card>
          <StateCard>
            <h2 style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>
              <Zap size={24} style={{ display: 'inline', marginRight: '0.5rem' }} />
              {result.state}
            </h2>
          </StateCard>
          <h3 style={{ marginBottom: '1rem' }}>Suggestion:</h3>
          <p style={{ fontSize: '1.125rem', marginBottom: '1.5rem' }}>{result.suggestion.text}</p>
          <h4 style={{ marginBottom: '0.5rem' }}>Why?</h4>
          <ul style={{ paddingLeft: '1.5rem' }}>
            {result.suggestion.evidence.map((ev, idx) => (
              <li key={idx} style={{ marginBottom: '0.5rem', color: 'gray' }}>{ev}</li>
            ))}
          </ul>
        </Card>
      )}
    </Container>
  );
};

export default MoodWellness;


