import React, { useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { Navigation, MapPin } from 'lucide-react';
import { useIntermodalPlanning } from '../services/intermodal';

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const Card = styled(motion.div)`
  background: ${props => props.theme.cardBackground};
  border: 1px solid ${props => props.theme.border};
  border-radius: 16px;
  padding: 2rem;
  margin-bottom: 2rem;
`;

const Input = styled.input`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid ${props => props.theme.border};
  border-radius: 8px;
  background: ${props => props.theme.background};
  color: ${props => props.theme.text};
  margin-bottom: 1rem;
`;

const Select = styled.select`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid ${props => props.theme.border};
  border-radius: 8px;
  background: ${props => props.theme.background};
  color: ${props => props.theme.text};
  margin-bottom: 1rem;
`;

const Button = styled(motion.button)`
  width: 100%;
  padding: 1rem;
  background: ${props => props.theme.gradient};
  color: white;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
`;

const RouteCard = styled.div`
  padding: 1rem;
  background: ${props => props.theme.background};
  border: 1px solid ${props => props.theme.border};
  border-radius: 8px;
  margin-bottom: 0.5rem;
`;

const Intermodal = () => {
  const [formData, setFormData] = useState({
    origin: '',
    arrival_time: '18:00',
    priority: 'fast'
  });
  const [result, setResult] = useState(null);
  const planningMutation = useIntermodalPlanning();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await planningMutation.mutateAsync(formData);
      setResult(response);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Container>
      <Title><Navigation size={32} /> Door-to-Door Transport</Title>
      
      <Card initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <form onSubmit={handleSubmit}>
          <Input
            placeholder="Starting location"
            value={formData.origin}
            onChange={(e) => setFormData({...formData, origin: e.target.value})}
            required
          />
          <Input
            type="time"
            value={formData.arrival_time}
            onChange={(e) => setFormData({...formData, arrival_time: e.target.value})}
            required
          />
          <Select
            value={formData.priority}
            onChange={(e) => setFormData({...formData, priority: e.target.value})}
          >
            <option value="fast">Fastest Route</option>
            <option value="eco">Most Eco-Friendly</option>
            <option value="cheap">Cheapest</option>
          </Select>
          <Button type="submit" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            {planningMutation.isLoading ? 'Planning...' : 'Plan Route'}
          </Button>
        </form>
      </Card>

      {result && (
        <Card>
          <h3>Your Route ({result.total_duration_min} min, ${result.total_cost})</h3>
          {result.routes.map((segment, idx) => (
            <RouteCard key={idx}>
              <strong>{segment.mode}</strong> - {segment.duration_min} min
              <div style={{ fontSize: '0.875rem', color: 'gray', marginTop: '0.5rem' }}>
                {segment.instructions}
              </div>
            </RouteCard>
          ))}
          <p style={{ marginTop: '1rem' }}>
            <strong>Depart at:</strong> {result.recommended_departure} | 
            <strong> CO2:</strong> {result.total_co2_kg} kg
          </p>
        </Card>
      )}
    </Container>
  );
};

export default Intermodal;

