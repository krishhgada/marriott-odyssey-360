import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import styled, { ThemeProvider, createGlobalStyle } from 'styled-components';

// Components
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import LoginModal from './components/LoginModal';
import LoadingScreen from './components/LoadingScreen';

// Pages
import Dashboard from './pages/Dashboard';
import Concierge from './pages/Concierge';
import RoomControl from './pages/RoomControl';
import Wellness from './pages/Wellness';
import LocalDiscovery from './pages/LocalDiscovery';
import Settings from './pages/Settings';

// New Pages
import Privacy from './pages/Privacy';
import CultureAccessibility from './pages/CultureAccessibility';
import TrustLens from './pages/TrustLens';
import Intermodal from './pages/Intermodal';
import AgentOps from './pages/AgentOps';
import MoodWellness from './pages/MoodWellness';
import Metrics from './pages/Metrics';

// Hooks and Context
import { useAuth } from './hooks/useAuth';
import { useTheme } from './hooks/useTheme';
import { FeatureFlagsProvider } from './context/FeatureFlagsContext';

// Global styles
const GlobalStyle = createGlobalStyle`
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
    background: ${props => props.theme.background};
    color: ${props => props.theme.text};
    line-height: 1.6;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  #root {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
  }

  /* Scrollbar styling */
  ::-webkit-scrollbar {
    width: 8px;
  }

  ::-webkit-scrollbar-track {
    background: ${props => props.theme.background};
  }

  ::-webkit-scrollbar-thumb {
    background: ${props => props.theme.primary};
    border-radius: 4px;
  }

  ::-webkit-scrollbar-thumb:hover {
    background: ${props => props.theme.primaryDark};
  }

  /* Focus styles for accessibility */
  *:focus {
    outline: 2px solid ${props => props.theme.primary};
    outline-offset: 2px;
  }

  /* High contrast mode support */
  @media (prefers-contrast: high) {
    * {
      border-color: currentColor !important;
    }
  }

  /* Reduced motion support */
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
    }
  }
`;

// Main app container
const AppContainer = styled.div`
  display: flex;
  min-height: 100vh;
  background: ${props => props.theme.background};
`;

const MainContent = styled.main`
  flex: 1;
  display: flex;
  flex-direction: column;
  margin-left: ${props => props.sidebarOpen ? '280px' : '0'};
  transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  
  @media (max-width: 768px) {
    margin-left: 0;
  }
`;

const ContentArea = styled.div`
  flex: 1;
  padding: 2rem;
  background: ${props => props.theme.background};
  
  @media (max-width: 768px) {
    padding: 1rem;
  }
`;

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true); // Start with sidebar open on desktop
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  const { isAuthenticated, user, login, logout } = useAuth();
  const { theme, toggleDarkMode } = useTheme();

  // Simulate app initialization
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  // Show loading screen during initialization
  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <>
      <FeatureFlagsProvider>
        <ThemeProvider theme={theme}>
          <GlobalStyle />
          <Router>
            <AppContainer>
              <Sidebar 
                isOpen={sidebarOpen} 
                onClose={() => setSidebarOpen(false)}
                isAuthenticated={isAuthenticated}
                user={user}
                onLogout={logout}
              />
              
              <MainContent sidebarOpen={sidebarOpen}>
                <Header 
                  onMenuClick={() => setSidebarOpen(!sidebarOpen)}
                  onLoginClick={() => setShowLoginModal(true)}
                  onLogoutClick={logout}
                  isAuthenticated={isAuthenticated}
                  user={user}
                  onThemeToggle={toggleDarkMode}
                />
                
                <ContentArea>
                  <Routes>
                    <Route path="/" element={<Dashboard />} />
                    <Route path="/concierge" element={<Concierge />} />
                    <Route path="/room" element={<RoomControl />} />
                    <Route path="/wellness" element={<Wellness />} />
                    <Route path="/discovery" element={<LocalDiscovery />} />
                    <Route path="/settings" element={<Settings />} />
                    
                    {/* New Feature Routes */}
                    <Route path="/privacy" element={<Privacy />} />
                    <Route path="/culture" element={<CultureAccessibility />} />
                    <Route path="/trustlens" element={<TrustLens />} />
                    <Route path="/intermodal" element={<Intermodal />} />
                    <Route path="/agentops" element={<AgentOps />} />
                    <Route path="/mood" element={<MoodWellness />} />
                    <Route path="/metrics" element={<Metrics />} />
                    
                    <Route path="*" element={<Navigate to="/" replace />} />
                  </Routes>
                </ContentArea>
              </MainContent>
            </AppContainer>
          </Router>

          {/* Login Modal */}
          {showLoginModal && (
            <LoginModal 
              onClose={() => setShowLoginModal(false)}
              onLogin={login}
            />
          )}

          {/* Toast notifications */}
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: theme.cardBackground,
                color: theme.text,
                border: `1px solid ${theme.border}`,
                borderRadius: '12px',
                boxShadow: theme.shadowMedium,
              },
              success: {
                iconTheme: {
                  primary: theme.success,
                  secondary: theme.background,
                },
              },
              error: {
                iconTheme: {
                  primary: theme.error,
                  secondary: theme.background,
                },
              },
            }}
          />
        </ThemeProvider>
      </FeatureFlagsProvider>
    </>
  );
}

export default App;
