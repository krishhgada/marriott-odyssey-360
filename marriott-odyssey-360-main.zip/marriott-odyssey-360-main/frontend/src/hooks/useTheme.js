import { useState, useEffect, createContext, useContext } from 'react';

// Theme context
const ThemeContext = createContext();

// Theme configurations
const themes = {
  light: {
    name: 'light',
    background: '#ffffff',
    cardBackground: '#ffffff',
    text: '#1f2937',
    textSecondary: '#6b7280',
    primary: '#E31837',
    primaryDark: '#C41E3A',
    secondary: '#1B365D',
    success: '#10B981',
    warning: '#F59E0B',
    error: '#EF4444',
    border: '#e5e7eb',
    hoverBackground: '#f9fafb',
    gradient: 'linear-gradient(135deg, #E31837 0%, #1B365D 100%)',
    shadowSoft: '0 4px 20px rgba(0, 0, 0, 0.1)',
    shadowMedium: '0 8px 30px rgba(0, 0, 0, 0.15)',
    shadowStrong: '0 12px 40px rgba(0, 0, 0, 0.2)',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  },
  dark: {
    name: 'dark',
    background: '#0f172a',
    cardBackground: '#1e293b',
    text: '#f1f5f9',
    textSecondary: '#94a3b8',
    primary: '#E31837',
    primaryDark: '#C41E3A',
    secondary: '#1B365D',
    success: '#10B981',
    warning: '#F59E0B',
    error: '#EF4444',
    border: '#334155',
    hoverBackground: '#334155',
    gradient: 'linear-gradient(135deg, #E31837 0%, #1B365D 100%)',
    shadowSoft: '0 4px 20px rgba(0, 0, 0, 0.3)',
    shadowMedium: '0 8px 30px rgba(0, 0, 0, 0.4)',
    shadowStrong: '0 12px 40px rgba(0, 0, 0, 0.5)',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  },
  marriott: {
    name: 'marriott',
    background: 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)',
    cardBackground: '#ffffff',
    text: '#1e293b',
    textSecondary: '#64748b',
    primary: '#E31837',
    primaryDark: '#C41E3A',
    secondary: '#1B365D',
    success: '#059669',
    warning: '#d97706',
    error: '#dc2626',
    border: '#e2e8f0',
    hoverBackground: '#f1f5f9',
    gradient: 'linear-gradient(135deg, #E31837 0%, #1B365D 100%)',
    shadowSoft: '0 4px 20px rgba(227, 24, 55, 0.1)',
    shadowMedium: '0 8px 30px rgba(227, 24, 55, 0.15)',
    shadowStrong: '0 12px 40px rgba(227, 24, 55, 0.2)',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  }
};

// Theme provider component
export const ThemeProvider = ({ children }) => {
  const [currentTheme, setCurrentTheme] = useState('marriott');
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Load theme preference from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('odyssey-theme');
    const savedDarkMode = localStorage.getItem('odyssey-dark-mode') === 'true';
    
    if (savedTheme && themes[savedTheme]) {
      setCurrentTheme(savedTheme);
    }
    
    setIsDarkMode(savedDarkMode);
  }, []);

  // Apply theme to document
  useEffect(() => {
    const root = document.documentElement;
    const theme = isDarkMode ? 'dark' : currentTheme;
    
    // Apply CSS custom properties
    Object.entries(themes[theme]).forEach(([key, value]) => {
      if (key !== 'name') {
        root.style.setProperty(`--${key.replace(/([A-Z])/g, '-$1').toLowerCase()}`, value);
      }
    });
    
    // Update body class for theme-specific styles
    document.body.className = `theme-${theme}`;
    
    // Save preferences
    localStorage.setItem('odyssey-theme', currentTheme);
    localStorage.setItem('odyssey-dark-mode', isDarkMode.toString());
  }, [currentTheme, isDarkMode]);

  // Toggle dark mode
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  // Set specific theme
  const setTheme = (themeName) => {
    if (themes[themeName]) {
      setCurrentTheme(themeName);
    }
  };

  // Get current theme object
  const getCurrentTheme = () => {
    return themes[isDarkMode ? 'dark' : currentTheme];
  };

  const value = {
    theme: getCurrentTheme(),
    currentTheme: isDarkMode ? 'dark' : currentTheme,
    isDarkMode,
    toggleDarkMode,
    setTheme,
    availableThemes: Object.keys(themes),
  };

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
};

// Custom hook to use theme context
export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

// Theme-aware styled component helper
export const withTheme = (Component) => {
  return (props) => {
    const { theme } = useTheme();
    return <Component {...props} theme={theme} />;
  };
};
