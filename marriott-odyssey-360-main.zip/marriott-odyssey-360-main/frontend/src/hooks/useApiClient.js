import { useMemo } from 'react';
import axios from 'axios';
import { useAuth } from './useAuth';
import toast from 'react-hot-toast';

/**
 * Custom hook to create an authenticated API client
 * Automatically injects the authorization header from auth context
 * 
 * @returns {Object} Axios instance with auth headers and error handling
 * 
 * @example
 * const api = useApiClient();
 * const response = await api.post('/api/privacy/recommend', data);
 */
export const useApiClient = () => {
  const { isAuthenticated } = useAuth();

  const apiClient = useMemo(() => {
    const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

    // Create axios instance
    const client = axios.create({
      baseURL: API_BASE_URL,
      headers: {
        'Content-Type': 'application/json',
      },
      timeout: 30000, // 30 second timeout
    });

    // Request interceptor - add auth token
    client.interceptors.request.use(
      (config) => {
        // Get token from localStorage
        const token = localStorage.getItem('access_token');
        
        // For demo mode, use demo token if no real token
        const demoToken = 'demo-token-odyssey360';
        const authToken = token || demoToken;
        
        if (authToken) {
          config.headers.Authorization = `Bearer ${authToken}`;
        }
        
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // Response interceptor - handle errors
    client.interceptors.response.use(
      (response) => response,
      (error) => {
        // Handle different error types
        if (error.response) {
          // Server responded with error status
          const { status, data } = error.response;
          
          switch (status) {
            case 401:
              toast.error('Authentication required. Please log in.');
              break;
            case 403:
              toast.error('Access forbidden. You don\'t have permission.');
              break;
            case 404:
              toast.error('Resource not found.');
              break;
            case 500:
              toast.error('Server error. Please try again later.');
              break;
            default:
              toast.error(data?.detail || 'An error occurred.');
          }
        } else if (error.request) {
          // Request made but no response
          toast.error('No response from server. Check your connection.');
        } else {
          // Error setting up request
          toast.error('Request failed. Please try again.');
        }
        
        return Promise.reject(error);
      }
    );

    return client;
  }, [isAuthenticated]);

  return apiClient;
};

/**
 * Helper function to make GET request
 */
export const useGet = () => {
  const api = useApiClient();
  return (url, config) => api.get(url, config);
};

/**
 * Helper function to make POST request
 */
export const usePost = () => {
  const api = useApiClient();
  return (url, data, config) => api.post(url, data, config);
};

/**
 * Helper function to make PUT request
 */
export const usePut = () => {
  const api = useApiClient();
  return (url, data, config) => api.put(url, data, config);
};

/**
 * Helper function to make DELETE request
 */
export const useDelete = () => {
  const api = useApiClient();
  return (url, config) => api.delete(url, config);
};

export default useApiClient;


