import { useApiClient } from '../hooks/useApiClient';
import { useMutation } from 'react-query';
import toast from 'react-hot-toast';

export const usePolicyAnswer = () => {
  const api = useApiClient();

  return useMutation(
    async (data) => {
      const response = await api.post('/api/agentops/answer', data);
      return response.data;
    },
    {
      onError: (error) => {
        toast.error(error.response?.data?.detail || 'Failed to get policy answer');
      },
    }
  );
};

export const useDraftReply = () => {
  const api = useApiClient();

  return useMutation(
    async (data) => {
      const response = await api.post('/api/agentops/draft_reply', data);
      return response.data;
    },
    {
      onError: (error) => {
        toast.error(error.response?.data?.detail || 'Failed to draft reply');
      },
    }
  );
};


