/**
 * Privacy API Service
 * Handles privacy recommendations and settings
 */

import { useApiClient } from '../hooks/useApiClient';
import { useMutation } from 'react-query';
import toast from 'react-hot-toast';

/**
 * Hook to get privacy recommendations
 */
export const usePrivacyRecommendation = () => {
  const api = useApiClient();

  return useMutation(
    async (data) => {
      const response = await api.post('/api/privacy/recommend', data);
      return response.data;
    },
    {
      onSuccess: () => {
        toast.success('Privacy recommendations generated successfully');
      },
      onError: (error) => {
        toast.error(error.response?.data?.detail || 'Failed to get privacy recommendations');
      },
    }
  );
};

/**
 * Get privacy recommendation directly (without React Query)
 */
export const getPrivacyRecommendation = async (api, data) => {
  const response = await api.post('/api/privacy/recommend', data);
  return response.data;
};


