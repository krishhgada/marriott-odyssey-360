/**
 * Culture & Accessibility API Service
 */

import { useApiClient } from '../hooks/useApiClient';
import { useMutation } from 'react-query';
import toast from 'react-hot-toast';

/**
 * Hook to get cultural adaptation
 */
export const useCultureAdaptation = () => {
  const api = useApiClient();

  return useMutation(
    async (data) => {
      const response = await api.post('/api/culture/adapt', data);
      return response.data;
    },
    {
      onSuccess: () => {
        toast.success('Cultural preferences applied successfully');
      },
      onError: (error) => {
        toast.error(error.response?.data?.detail || 'Failed to get cultural adaptation');
      },
    }
  );
};


