import { useApiClient } from '../hooks/useApiClient';
import { useMutation } from 'react-query';
import toast from 'react-hot-toast';

export const useInsightsPrediction = () => {
  const api = useApiClient();

  return useMutation(
    async (data) => {
      const response = await api.post('/api/insights/predict', data);
      return response.data;
    },
    {
      onSuccess: () => {
        toast.success('Insights generated successfully');
      },
      onError: (error) => {
        toast.error(error.response?.data?.detail || 'Failed to generate insights');
      },
    }
  );
};


