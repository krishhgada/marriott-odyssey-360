import { useApiClient } from '../hooks/useApiClient';
import { useMutation } from 'react-query';
import toast from 'react-hot-toast';

export const useIntermodalPlanning = () => {
  const api = useApiClient();

  return useMutation(
    async (data) => {
      const response = await api.post('/api/intermodal/plan', data);
      return response.data;
    },
    {
      onSuccess: () => {
        toast.success('Route plan generated successfully');
      },
      onError: (error) => {
        toast.error(error.response?.data?.detail || 'Failed to generate route');
      },
    }
  );
};


