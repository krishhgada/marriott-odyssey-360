import { useApiClient } from '../hooks/useApiClient';
import { useQuery } from 'react-query';

export const useMetrics = () => {
  const api = useApiClient();

  return useQuery(
    'metrics',
    async () => {
      const response = await api.get('/api/metrics');
      return response.data;
    },
    {
      refetchInterval: 5000, // Refresh every 5 seconds
      retry: 2,
    }
  );
};


