/**
 * TrustLens API Service
 * Content authenticity checking
 */

import { useApiClient } from '../hooks/useApiClient';
import { useMutation } from 'react-query';
import toast from 'react-hot-toast';

/**
 * Hook to check image authenticity
 */
export const useImageTrustCheck = () => {
  const api = useApiClient();

  return useMutation(
    async (data) => {
      const response = await api.post('/api/trust/check_image', data);
      return response.data;
    },
    {
      onSuccess: (data) => {
        if (data.trust_score >= 80) {
          toast.success('Image authenticity verified');
        } else if (data.trust_score >= 60) {
          toast('Use caution with this image', { icon: '⚠️' });
        } else {
          toast.error('High risk image detected');
        }
      },
      onError: (error) => {
        toast.error(error.response?.data?.detail || 'Failed to check image authenticity');
      },
    }
  );
};


